function app = DynoForge_Signal_Quality_Display()
% DynoForge Step 10.8 - offline quality status UI.
% No Simulink commands, model writes, or hardware access.
    names = {'FORCE','RPM','INLET TEMP','OUTLET TEMP','FLOW'};
    bits = uint8([1 2 4 8 16]);
    counts = zeros(1,5);
    cases = {'ALL_OK','FORCE_FAULT','MULTIPLE_FAULTS','WARNING_ONLY','UNKNOWN'};
    fig = uifigure('Name','DynoForge | Step 10.8 Signal Quality', ...
        'Position',[130 130 1000 620],'Color',[0.08 0.10 0.14]);
    fig.CloseRequestFcn = @(~,~)delete(fig);
    grid = uigridlayout(fig,[5 1]);
    grid.RowHeight = {55,65,170,65,'1x'};
    grid.Padding = [16 12 16 12];
    grid.BackgroundColor = [0.08 0.10 0.14];
    h = uilabel(grid,'Text','DYNOFORGE | SIGNAL QUALITY MONITOR - OFFLINE DEMO', ...
        'FontSize',19,'FontWeight','bold','FontColor',[1 1 1]);
    h.Layout.Row=1;
    controls = uigridlayout(grid,[1 5]); controls.Layout.Row=2;
    controls.ColumnWidth={'1x','1x','1x','1x','1x'};
    controls.BackgroundColor=[0.08 0.10 0.14];
    captions = {'ALL OK','FORCE FAULT','MULTIPLE FAULTS','WARNING ONLY','CLEAR / UNKNOWN'};
    for k=1:5
        idx=k;
        uibutton(controls,'push','Text',captions{k},'ButtonPushedFcn',@(~,~)applyCase(idx));
    end
    cards = uigridlayout(grid,[1 5]); cards.Layout.Row=3;
    cards.ColumnWidth={'1x','1x','1x','1x','1x'};
    cards.BackgroundColor=[0.08 0.10 0.14];
    indicators = gobjects(1,5);
    for k=1:5
        panel=uipanel(cards,'Title',names{k},'ForegroundColor',[1 1 1], ...
            'BackgroundColor',[0.13 0.16 0.21]);
        indicators(k)=uilabel(panel,'Text','UNKNOWN','Position',[10 45 145 50], ...
            'HorizontalAlignment','center','FontSize',16,'FontWeight','bold', ...
            'FontColor',[1 .72 .25]);
    end
    summary=uilabel(grid,'Text','Overall: UNKNOWN | Warning: UNKNOWN | Fault Code: UNKNOWN', ...
        'FontSize',15,'FontColor',[1 .72 .25]); summary.Layout.Row=4;
    log=uitextarea(grid,'Editable','off','Value', ...
        {'[INFO] Offline demonstration initialized','[SAFE] No Simulink writes or hardware access'});
    log.Layout.Row=5;
    setappdata(fig,'DynoForgeSQCounts',counts);
    setappdata(fig,'DynoForgeSQCaseNames',cases);
    setappdata(fig,'DynoForgeSQGetReport',@report);
    app=fig;
    fprintf('\n===== STEP 10.8 SIGNAL QUALITY =====\n');
    fprintf('PASS | Window created; 5 sensor indicators initialized UNKNOWN\n');
    fprintf('PASS | Offline callbacks installed; no hardware or Simulink access\n');
    fprintf('Click all five test buttons, then run DynoForge_Signal_Quality_Test_Report\n');
    fprintf('====================================\n');

    function applyCase(idx)
        counts(idx)=counts(idx)+1;
        switch idx
            case 1
                code=uint8(0); warning=false; known=true; overall=true;
            case 2
                code=uint8(1); warning=true; known=true; overall=false;
            case 3
                code=uint8(5); warning=true; known=true; overall=false;
            case 4
                code=uint8(0); warning=true; known=true; overall=true;
            otherwise
                code=uint8(0); warning=false; known=false; overall=false;
        end
        for j=1:5
            if ~known
                indicators(j).Text='UNKNOWN'; indicators(j).FontColor=[1 .72 .25];
            elseif bitand(code,bits(j))~=0
                indicators(j).Text='FAULT'; indicators(j).FontColor=[1 .32 .32];
            else
                indicators(j).Text='OK'; indicators(j).FontColor=[.30 .90 .57];
            end
        end
        if known
            if overall, overallText='OK'; else, overallText='FAULT'; end
            if warning, warningText='YES'; else, warningText='NO'; end
            summary.Text=sprintf('Overall: %s | Warning: %s | Fault Code: %d', ...
                overallText,warningText,code);
        else
            summary.Text='Overall: UNKNOWN | Warning: UNKNOWN | Fault Code: UNKNOWN';
        end
        entry=sprintf('[DEMO] %s | %s',cases{idx},summary.Text);
        log.Value=[log.Value;{entry}];
        setappdata(fig,'DynoForgeSQCounts',counts);
        setappdata(fig,'DynoForgeSQLastCase',cases{idx});
    end
    function report()
        c=getappdata(fig,'DynoForgeSQCounts');
        fprintf('\n===== STEP 10.8 OFFLINE VERIFICATION =====\n');
        for q=1:5
            if c(q)>0, status='PASS'; else, status='NOT TESTED'; end
            fprintf('%s | %s: %d test(s)\n',status,cases{q},c(q));
        end
        if all(c>0)
            fprintf('STEP 10.8 OFFLINE DISPLAY TEST PASSED\n');
        else
            fprintf('STEP 10.8 INCOMPLETE: test all five buttons\n');
        end
        fprintf('Live Simulink and hardware data: NOT TESTED\n');
        fprintf('==========================================\n');
    end
end
