function DynoForge_Data_Logger_Test_Report()
% DynoForge Step 10.12 - verify exported OFFLINE CSV by reading it back.
% No Simulink execution, model changes, or hardware access.

    file = fullfile(pwd, 'Results', 'Step_10_12', ...
        'DynoForge_Offline_Demo_Data.csv');
    fprintf('\n===== STEP 10.12 OFFLINE VERIFICATION =====\n');
    if ~exist(file, 'file')
        fprintf('FAIL | FILE_EXISTS\n');
        fprintf('STEP 10.12 FAILED: CSV not found.\n');
        return;
    end
    T = readtable(file);
    expected = {'Time_s','Force_N','RPM_rpm','Torque_Nm', ...
        'AngularVelocity_rad_s','Power_kW','TempIn_degC', ...
        'TempOut_degC','Flow_Demo_L_min','AlarmLevel_Demo', ...
        'TestState_Demo','Calibration_Confirmed','Flow_Calibrated', ...
        'Data_Source'};
    namesOK = isequal(T.Properties.VariableNames, expected);
    sizeOK = (height(T) == 501) && (width(T) == 14);
    timeOK = sizeOK && all(abs(diff(T.Time_s)-0.02)<1e-10) ...
        && abs(T.Time_s(1))<1e-10 && abs(T.Time_s(end)-10)<1e-10;
    numeric = T{:,1:13};
    finiteOK = all(isfinite(numeric(:)));
    rangeOK = all(T.RPM_rpm >= 0) && all(T.Force_N >= 0) ...
        && all(T.Flow_Demo_L_min >= 0);
    torqueOK = all(abs(T.Torque_Nm - T.Force_N*0.3048)<1e-8);
    omegaOK = all(abs(T.AngularVelocity_rad_s ...
        - T.RPM_rpm*2*pi/60)<1e-8);
    powerOK = all(abs(T.Power_kW ...
        - T.Torque_Nm.*T.AngularVelocity_rad_s/1000)<1e-8);
    sourceOK = all(strcmp(T.Data_Source, 'OFFLINE_SYNTHETIC'));
    calibrationOK = all(T.Calibration_Confirmed==0) ...
        && all(T.Flow_Calibrated==0);
    results = [true, namesOK, sizeOK, timeOK, finiteOK, rangeOK, ...
        torqueOK, omegaOK, powerOK, sourceOK, calibrationOK];
    labels = {'FILE_EXISTS','COLUMN_NAMES','ROW_COLUMN_COUNT', ...
        'TIME_ORDER_50HZ','FINITE_VALUES','VALID_RANGES', ...
        'TORQUE_CONSISTENCY','OMEGA_CONSISTENCY', ...
        'POWER_CONSISTENCY','SYNTHETIC_SOURCE_LABEL', ...
        'CALIBRATION_NOT_CONFIRMED'};
    for k = 1:numel(results)
        if results(k), status = 'PASS'; else, status = 'FAIL'; end
        fprintf('%s | %s\n', status, labels{k});
    end
    if all(results)
        fprintf('STEP 10.12 OFFLINE CSV TEST PASSED\n');
    else
        fprintf('STEP 10.12 OFFLINE CSV TEST FAILED\n');
    end
    fprintf('Live Simulink logging: NOT TESTED\n');
    fprintf('Hardware/calibration: NOT TESTED\n');
    fprintf('==========================================\n');
end
