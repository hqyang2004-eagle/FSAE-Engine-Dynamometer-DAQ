function app = DynoForge_Alarm_Display()
% DynoForge Step 10.10 - OFFLINE alarm and safety display verification.
% No Simulink commands, model writes, or hardware access.

names = {'NORMAL','CALIBRATION INCOMPLETE', ...
    'SENSOR / CALIBRATION FAULT','SHUTDOWN'};
scenarios = {'NORMAL','CAL_INCOMPLETE','SENSOR_FAULT', ...
    'CAL_INVALID','MULTIPLE_FAULTS','SHUTDOWN','UNKNOWN'};
counts = zeros(1,numel(scenarios));
results = false(1,numel(scenarios));
logEntries = {'[INFO] Step 10.10 offline monitor initialized'; ...
    '[SAFE] Display-only demonstration; Simulink disconnected'};

fig = uifigure('Name','DynoForge | Step 10.10 Alarm & Safety Monitor', ...
    'Position',[150 120 1020 680],'Color',[0.08 0.10 0.14]);
fig.CloseRequestFcn = @(~,~) delete(fig);
root = uigridlayout(fig,[5 1]);
root.RowHeight = {55,75,220,55,'1x'};
root.Padding = [16 14 16 14];
root.RowSpacing = 10;
root.BackgroundColor = [0.08 0.10 0.14];

header = uilabel(root,'Text','DYNOFORGE | ALARM & SAFETY MONITOR', ...
    'FontSize',22,'FontWeight','bold','FontColor',[0.94 0.96 1]);
header.Layout.Row = 1;

buttons = uigridlayout(root,[1 8]);
buttons.Layout.Row = 2;
buttons.ColumnWidth = repmat({'1x'},1,8);
buttons.ColumnSpacing = 5;
buttons.Padding = [0 0 0 0];
buttons.BackgroundColor = [0.08 0.10 0.14];
labels = {'NORMAL','CAL INCOMPLETE','SENSOR FAULT','CAL INVALID', ...
    'MULTIPLE','SHUTDOWN','UNKNOWN','RUN ALL TESTS'};
for k=1:8
    idx=k;
    b=uibutton(buttons,'push','Text',labels{k},'FontSize',10, ...
        'ButtonPushedFcn',@(~,~) clickScenario(idx));
    b.Layout.Column=k;
end

panel=uipanel(root,'Title','ALARM STATUS / BITMASK', ...
    'BackgroundColor',[0.12 0.16 0.22], ...
    'ForegroundColor',[0.94 0.96 1], 'FontWeight','bold');
panel.Layout.Row=3;
g=uigridlayout(panel,[7 2]);
g.RowHeight=repmat({'1x'},1,7);
g.ColumnWidth={'1x','1x'};
g.BackgroundColor=[0.12 0.16 0.22];
fieldNames={'ALARM LEVEL','ALARM ACTIVE','ALARM CODE', ...
    'SENSOR FAULT (BIT 0)','CAL PARAM INVALID (BIT 1)', ...
    'CAL INCOMPLETE (BIT 2)','SHUTDOWN (BIT 3)'};
valueLabels=gobjects(1,7);
for k=1:7
    lab=uilabel(g,'Text',fieldNames{k},'FontColor',[0.72 0.82 0.95], ...
        'FontSize',13,'FontWeight','bold');
    lab.Layout.Row=k; lab.Layout.Column=1;
    val=uilabel(g,'Text','UNKNOWN','FontColor',[1 0.72 0.28], ...
        'FontSize',13,'FontWeight','bold');
    val.Layout.Row=k; val.Layout.Column=2;
    valueLabels(k)=val;
end

safety=uilabel(root,'Text', ...
    'OFFLINE DEMO | NO LIVE ALARM DATA | NOT AN EMERGENCY-STOP DEVICE', ...
    'FontSize',12,'FontWeight','bold','FontColor',[1 0.69 0.22]);
safety.Layout.Row=4;
logBox=uitextarea(root,'Editable','off','Value',logEntries, ...
    'BackgroundColor',[0.07 0.08 0.10], ...
    'FontColor',[0.90 0.94 1],'FontSize',11);
logBox.Layout.Row=5;

setappdata(fig,'DynoForgeAlarmReport',@report);
app=struct('Figure',fig,'Report',@report);
fprintf('\n===== STEP 10.10 ALARM DISPLAY =====\n');
fprintf('PASS | Offline alarm display created\n');
fprintf('PASS | 7 demonstration scenarios available\n');
fprintf('No Simulink writes or hardware access.\n');
fprintf('Run DynoForge_Alarm_Test_Report after RUN ALL TESTS.\n');
fprintf('====================================\n');

    function clickScenario(idx)
        if idx==8
            for j=1:7
                applyScenario(j);
            end
        else
            applyScenario(idx);
        end
    end

    function applyScenario(idx)
        % Expected: level, active, bitmask. These are UI fixtures only.
        fixtures=[0 0 0; 1 1 4; 2 1 1; 2 1 2; ...
                  2 1 7; 3 1 8];
        counts(idx)=counts(idx)+1;
        if idx==7
            values=repmat({'UNKNOWN'},1,7);
            valid=true;
        else
            v=fixtures(idx,:);
            level=v(1); active=v(2); code=v(3);
            bits=[1 2 4 8];
            values=cell(1,7);
            values{1}=sprintf('%d | %s',level,names{level+1});
            values{2}=ternary(active==1,'YES','NO');
            values{3}=sprintf('%d',code);
            for n=1:4
                values{n+3}=ternary(bitand(uint8(code),uint8(bits(n)))~=0, ...
                    'ACTIVE','CLEAR');
            end
            decoded=0;
            for n=1:4
                if strcmp(values{n+3},'ACTIVE')
                    decoded=decoded+bits(n);
                end
            end
            valid=(decoded==code) && ...
                (active==double(level>0)) && ...
                (level==expectedLevel(code));
        end
        for n=1:7
            valueLabels(n).Text=values{n};
            if idx==6
                valueLabels(n).FontColor=[1 0.30 0.30];
            elseif idx==1
                valueLabels(n).FontColor=[0.40 0.91 0.65];
            else
                valueLabels(n).FontColor=[1 0.72 0.28];
            end
        end
        results(idx)=results(idx) || valid;
        logEntries{end+1}=sprintf('[DEMO] %s | %s',scenarios{idx}, ...
            ternary(valid,'PASS','FAIL'));
        logBox.Value=logEntries;
    end

    function level=expectedLevel(code)
        if bitand(uint8(code),uint8(8))~=0
            level=3;
        elseif bitand(uint8(code),uint8(3))~=0
            level=2;
        elseif bitand(uint8(code),uint8(4))~=0
            level=1;
        else
            level=0;
        end
    end

    function report()
        fprintf('\n===== STEP 10.10 OFFLINE VERIFICATION =====\n');
        for n=1:numel(scenarios)
            if counts(n)>0 && results(n)
                verdict='PASS';
            elseif counts(n)==0
                verdict='NOT TESTED';
            else
                verdict='FAIL';
            end
            fprintf('%s | %s: %d test(s)\n',verdict,scenarios{n},counts(n));
        end
        if all(counts>0) && all(results)
            fprintf('STEP 10.10 OFFLINE DISPLAY TEST PASSED\n');
        else
            fprintf('STEP 10.10 INCOMPLETE OR FAILED\n');
        end
        fprintf('Simulink integration: NOT TESTED\n');
        fprintf('Hardware safety interlocks: NOT TESTED\n');
        fprintf('==========================================\n');
    end
end

function result=ternary(condition,yes,no)
if condition
    result=yes;
else
    result=no;
end
end
