
%% DynoForge - Complete Automatic Test System
% Model: ME486C_Dyno_DAQ_Final_Version
% MATLAB R2025a
% OFFLINE simulation and post-test analysis only.
% This script does NOT physically stop an engine.

clc;
close all;

%% 1. Configuration
root = 'C:\DynoForge_Test';
model = 'ME486C_Dyno_DAQ_Final_Version';
modelFile = fullfile(root,[model '.slx']);

if ~isfile(modelFile)
    error('Simulink model not found: %s',modelFile);
end

stamp = datestr(now,'yyyymmdd_HHMMSS_FFF');
reportDir = fullfile(root,'Results', ...
    ['DynoForge_Test_' stamp]);

subfolders = { ...
    '01_Raw_Data', ...
    '02_Engineering_Plots', ...
    '03_Cooling_Plots', ...
    '04_Safety_and_Faults', ...
    '05_Data_Quality', ...
    '06_Dashboard', ...
    '07_Test_Report'};

for k = 1:numel(subfolders)
    mkdir(fullfile(reportDir,subfolders{k}));
end

fprintf('\n===== DynoForge Test System =====\n');
fprintf('Report folder: %s\n',reportDir);

%% 2. Run Simulink
load_system(modelFile);

fprintf('\nRunning OFFLINE simulation...\n');

simOut = sim(model, ...
    'StopTime','1', ...
    'SimulationMode','normal');

logs = simOut.logsout;

if isempty(logs) || logs.numElements == 0
    error('No logged signals found. Enable Signal Logging.');
end

save(fullfile(reportDir,'01_Raw_Data', ...
    'Original_Simulation.mat'),'simOut','-v7.3');

%% 3. Map Simulink output ports
engNames = { ...
    'Torque_Nm','Power_kW','Delta_T_C', ...
    'Cooling_Power_kW','OverTemp_Warning', ...
    'Temperature_Valid','Cooling_Valid', ...
    'Temperature_Fault_Warning'};

faultNames = { ...
    'OverTemp_Trip','Temp_Sensor_Trip', ...
    'Cooling_Data_Trip','Low_Flow_Trip', ...
    'Overspeed_Trip','RPM_Loss_Trip', ...
    'Start_Timeout_Fault','EStop_Trip', ...
    'Safety_Chain_Trip','Any_Trip', ...
    'Trip_Latched','Shutdown_Request', ...
    'Run_Permit','Controller_State', ...
    'Reset_Accepted','Fault_Code'};

sensorNames = { ...
    'Force_N','RPM','Temp_In_C','Temp_Out_C', ...
    'Sensor_Torque_Nm','RPM_raw','RPM_VALID', ...
    'New_pulse','zero_speed_Timeout', ...
    'Temp_In_Valid','Temp_In_Fault','Temp_In_Raw', ...
    'Temp_Out_Valid','Temp_Out_Fault','Temp_Out_Raw', ...
    'Flow_Pulse_delta','Flow_Hz','Flow_status_Raw', ...
    'Flow_Lmin','Flow_Valid','Flow_Pulse_Count'};

D = table();
skipped = strings(0,1);

for k = 1:logs.numElements
    sig = logs{k};

    bp = char(sig.BlockPath.getBlock(1));
    port = double(sig.PortIndex);

    if endsWith(bp,'/Engineering Calculations')
        names = engNames;
    elseif endsWith(bp,'/fault detection')
        names = faultNames;
    elseif endsWith(bp,'/Sensor Acquisition')
        names = sensorNames;
    else
        skipped(end+1,1) = "Unknown block: " + bp;
        continue;
    end

    if port < 1 || port > numel(names)
        skipped(end+1,1) = "Unknown port: " + bp;
        continue;
    end

    v = sig.Values;

    if ~isa(v,'timeseries')
        skipped(end+1,1) = "Not timeseries: " + bp;
        continue;
    end

    t = double(v.Time(:));
    y = double(v.Data);

    if ~isvector(y) || numel(y) ~= numel(t)
        skipped(end+1,1) = "Non-scalar signal: " + bp;
        continue;
    end

    if isempty(D)
        D = table(t,'VariableNames',{'Time_s'});
    end

    if height(D) ~= numel(t) || ...
       any(abs(D.Time_s-t)>1e-9)
        skipped(end+1,1) = "Different time base: " + bp;
        continue;
    end

    name = names{port};

    if ismember(name,D.Properties.VariableNames)
        skipped(end+1,1) = "Duplicate: " + name;
        continue;
    end

    D.(name) = y(:);
end

if height(D) < 2
    error('Insufficient aligned logged data.');
end

%% 4. Save CSV
csvFile = fullfile(reportDir,'01_Raw_Data', ...
    'All_Logged_Signals.csv');

writetable(D,csvFile);

writelines(skipped,fullfile(reportDir, ...
    '07_Test_Report','Skipped_Signals.txt'));

fprintf('CSV exported: %d rows, %d columns\n', ...
    height(D),width(D));

%% 5. Define 60 plots
% Each category contains 15 figures.
% Missing signals are marked N/A.

engineering = { ...
'Torque_Nm','Torque','signal'; ...
'Power_kW','Power','signal'; ...
'RPM','Engine RPM','signal'; ...
'Force_N','Load Cell Force','signal'; ...
'Torque_Nm','Torque Histogram','hist'; ...
'Power_kW','Power Histogram','hist'; ...
'Torque_Nm','Torque Moving Average','smooth'; ...
'Power_kW','Power Moving Average','smooth'; ...
'Torque_Nm','Torque Rate','rate'; ...
'Power_kW','Power Rate','rate'; ...
'Torque_Nm','Integrated Torque','integral'; ...
'Power_kW','Integrated Power','integral'; ...
'Torque_Nm','Torque Distribution','sorted'; ...
'Power_kW','Power Distribution','sorted'; ...
'RPM','RPM Moving Average','smooth'};

cooling = { ...
'Temp_In_C','Inlet Temperature','signal'; ...
'Temp_Out_C','Outlet Temperature','signal'; ...
'Delta_T_C','Temperature Difference','signal'; ...
'Cooling_Power_kW','Cooling Power','signal'; ...
'Flow_Lmin','Cooling Flow','signal'; ...
'Flow_Hz','Flow Frequency','signal'; ...
'Flow_Pulse_Count','Flow Pulse Count','signal'; ...
'Temp_In_C','Inlet Temperature Rate','rate'; ...
'Temp_Out_C','Outlet Temperature Rate','rate'; ...
'Delta_T_C','Delta T Moving Average','smooth'; ...
'Flow_Lmin','Flow Moving Average','smooth'; ...
'Temp_In_C','Inlet Temperature Histogram','hist'; ...
'Temp_Out_C','Outlet Temperature Histogram','hist'; ...
'Flow_Lmin','Flow Histogram','hist'; ...
'Cooling_Power_kW','Cooling Power Integral','integral'};

safety = { ...
'OverTemp_Trip','Overtemperature Trip','stairs'; ...
'Temp_Sensor_Trip','Temperature Sensor Trip','stairs'; ...
'Cooling_Data_Trip','Cooling Data Trip','stairs'; ...
'Low_Flow_Trip','Low Flow Trip','stairs'; ...
'Overspeed_Trip','Overspeed Trip','stairs'; ...
'RPM_Loss_Trip','RPM Loss Trip','stairs'; ...
'Start_Timeout_Fault','Startup Timeout','stairs'; ...
'EStop_Trip','Emergency Stop','stairs'; ...
'Safety_Chain_Trip','Safety Chain Trip','stairs'; ...
'Any_Trip','Any Trip','stairs'; ...
'Trip_Latched','Trip Latched','stairs'; ...
'Shutdown_Request','Shutdown Request','stairs'; ...
'Run_Permit','Run Permit','stairs'; ...
'Controller_State','Controller State','stairs'; ...
'Fault_Code','Fault Code','stairs'};

quality = { ...
'Temperature_Valid','Temperature Valid','stairs'; ...
'Cooling_Valid','Cooling Valid','stairs'; ...
'RPM_VALID','RPM Valid','stairs'; ...
'Flow_Valid','Flow Valid','stairs'; ...
'Temp_In_Fault','Inlet Sensor Fault','stairs'; ...
'Temp_Out_Fault','Outlet Sensor Fault','stairs'; ...
'Temperature_Fault_Warning','Temperature Warning','stairs'; ...
'OverTemp_Warning','Overtemp Warning','stairs'; ...
'Reset_Accepted','Reset Accepted','stairs'; ...
'zero_speed_Timeout','Zero Speed Timeout','stairs'; ...
'RPM_raw','Raw RPM','signal'; ...
'Temp_In_Raw','Raw Inlet Temperature','signal'; ...
'Temp_Out_Raw','Raw Outlet Temperature','signal'; ...
'Flow_status_Raw','Raw Flow Status','stairs'; ...
'Time_s','Sampling Interval','sampletime'};

categories = {engineering,cooling,safety,quality};

destinations = { ...
'02_Engineering_Plots', ...
'03_Cooling_Plots', ...
'04_Safety_and_Faults', ...
'05_Data_Quality'};

%% 6. Generate plots
plotLog = strings(0,4);
plotCount = 0;
naCount = 0;

for c = 1:4
    specs = categories{c};

    for p = 1:size(specs,1)
        name = specs{p,1};
        titleText = specs{p,2};
        mode = specs{p,3};

        fig = figure('Visible','off','Color','w', ...
            'Position',[100 100 1100 650]);

        hasData = ismember(name,D.Properties.VariableNames);

        if hasData
            y = D.(name);
            t = D.Time_s;

            switch mode
                case 'signal'
                    plot(t,y,'LineWidth',1.5);

                case 'stairs'
                    stairs(t,y,'LineWidth',1.5);

                case 'hist'
                    histogram(y(isfinite(y)));

                case 'smooth'
                    plot(t,movmean(y,5),'LineWidth',1.5);

                case 'rate'
                    dy = gradient(y,t);
                    plot(t,dy,'LineWidth',1.5);

                case 'integral'
                    plot(t,cumtrapz(t,y),'LineWidth',1.5);

                case 'sorted'
                    plot(sort(y),'LineWidth',1.5);

                case 'sampletime'
                    plot(t(2:end),diff(t),'LineWidth',1.5);
            end

            grid on;
            xlabel('Time / Sample / Value');
            ylabel(name);
        else
            text(0.5,0.5, ...
                ['N/A - Signal not logged: ' name], ...
                'Units','normalized', ...
                'HorizontalAlignment','center', ...
                'FontSize',15);
            axis off;
            naCount = naCount + 1;
        end

        title(['DynoForge - ' titleText], ...
            'Interpreter','none');

        filename = sprintf('%02d_%02d_%s.png', ...
            c,p,matlab.lang.makeValidName(name));

        target = fullfile(reportDir,destinations{c},filename);

        exportgraphics(fig,target,'Resolution',200);
        close(fig);

        plotCount = plotCount + 1;

        plotLog(end+1,:) = [ ...
            string(destinations{c}), ...
            string(titleText), ...
            string(name), ...
            string(hasData)];
    end
end

%% 7. Signal statistics
stats = table();

for k = 2:width(D)
    name = D.Properties.VariableNames{k};
    y = D.(name);
    valid = y(isfinite(y));

    if isempty(valid)
        continue;
    end

    newRow = table( ...
        string(name), ...
        min(valid), ...
        max(valid), ...
        mean(valid), ...
        std(valid), ...
        sum(~isfinite(y)), ...
        'VariableNames', ...
        {'Signal','Minimum','Maximum','Mean', ...
         'StdDev','InvalidSamples'});

    stats = [stats;newRow]; %#ok<AGROW>
end

writetable(stats,fullfile(reportDir, ...
    '07_Test_Report','Signal_Statistics.csv'));

%% 8. Fault event log
faultSignals = { ...
'OverTemp_Trip','Temp_Sensor_Trip', ...
'Cooling_Data_Trip','Low_Flow_Trip', ...
'Overspeed_Trip','RPM_Loss_Trip', ...
'Start_Timeout_Fault','EStop_Trip', ...
'Safety_Chain_Trip','Shutdown_Request'};

eventTime = [];
eventName = strings(0,1);

activeFaults = strings(0,1);

for k = 1:numel(faultSignals)
    name = faultSignals{k};

    if ~ismember(name,D.Properties.VariableNames)
        continue;
    end

    y = D.(name) ~= 0;
    rising = find(y & ~[false;y(1:end-1)]);

    for j = 1:numel(rising)
        eventTime(end+1,1) = D.Time_s(rising(j));
        eventName(end+1,1) = string(name);
    end

    if any(y)
        activeFaults(end+1,1) = string(name);
    end
end

events = table(eventTime,eventName, ...
    'VariableNames',{'Time_s','Event'});

if ~isempty(events)
    events = sortrows(events,'Time_s');
end

writetable(events,fullfile(reportDir, ...
    '04_Safety_and_Faults','Fault_Events.csv'));

%% 9. Combined dashboard
dashboardSignals = { ...
'RPM','Torque_Nm','Power_kW', ...
'Temp_In_C','Temp_Out_C','Flow_Lmin', ...
'Controller_State','Fault_Code', ...
'Shutdown_Request'};

fig = figure('Visible','off','Color','w', ...
    'Position',[100 100 1500 1000]);

for k = 1:numel(dashboardSignals)
    subplot(3,3,k);

    name = dashboardSignals{k};

    if ismember(name,D.Properties.VariableNames)
        plot(D.Time_s,D.(name),'LineWidth',1.5);
        grid on;
        xlabel('Time (s)');
    else
        text(0.5,0.5,'N/A', ...
            'Units','normalized', ...
            'HorizontalAlignment','center');
        axis off;
    end

    title(name,'Interpreter','none');
end

sgtitle('DynoForge - Test Dashboard');

exportgraphics(fig,fullfile(reportDir, ...
    '06_Dashboard','DynoForge_Dashboard.png'), ...
    'Resolution',200);

savefig(fig,fullfile(reportDir, ...
    '06_Dashboard','DynoForge_Dashboard.fig'));

close(fig);

%% 10. Plot manifest
manifest = array2table(plotLog, ...
    'VariableNames', ...
    {'Category','Plot','Signal','DataAvailable'});

writetable(manifest,fullfile(reportDir, ...
    '07_Test_Report','Plot_Manifest.csv'));

%% 11. Test summary
summaryFile = fullfile(reportDir, ...
    '07_Test_Report','Test_Summary.txt');

fid = fopen(summaryFile,'w');

fprintf(fid,'DynoForge Automatic Test Report\n');
fprintf(fid,'================================\n');
fprintf(fid,'Model: %s\n',model);
fprintf(fid,'Data source: OFFLINE SIMULINK SIMULATION\n');
fprintf(fid,'Test time: %s\n',stamp);
fprintf(fid,'Samples: %d\n',height(D));
fprintf(fid,'Logged channels: %d\n',width(D)-1);
fprintf(fid,'Plots: %d\n',plotCount);
fprintf(fid,'Plots marked N/A: %d\n',naCount);
fprintf(fid,'Fault events: %d\n',height(events));
fprintf(fid,'\nActive faults:\n');

for k = 1:numel(activeFaults)
    fprintf(fid,'%s\n',activeFaults(k));
end

fprintf(fid, ...
    '\nPhysical engine shutdown NOT verified.\n');

fclose(fid);

%% 12. Post-test alarm
if ~isempty(activeFaults)
    msg = sprintf( ...
        ['DynoForge simulation detected:\n%s\n\n' ...
         'This does not confirm physical shutdown.'], ...
        strjoin(cellstr(activeFaults),newline));

    fprintf('\nWARNING:\n%s\n',msg);

    try
        warndlg(msg,'DynoForge Fault Warning');
    catch
        warning('%s',msg);
    end
end

%% 13. Completion
fprintf('\n===== DynoForge Report Complete =====\n');
fprintf('Samples: %d\n',height(D));
fprintf('Channels: %d\n',width(D)-1);
fprintf('Plots: %d\n',plotCount);
fprintf('N/A plots: %d\n',naCount);
fprintf('Fault events: %d\n',height(events));
fprintf('Folder: %s\n',reportDir);
fprintf('PASS: Offline report generation finished.\n');
