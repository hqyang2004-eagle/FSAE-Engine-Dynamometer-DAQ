
#include <Arduino.h>

// DynoForge DAQ Firmware
// Stage 1: Serial protocol and timing test
// Target: Arduino UNO R4 Minima

constexpr uint32_t BAUD_RATE = 115200;
constexpr uint32_t SAMPLE_PERIOD_US = 20000; // 50 Hz

uint32_t lastSampleUs = 0;
uint32_t sequenceNumber = 0;

void setup() {
  Serial.begin(BAUD_RATE);
  lastSampleUs = micros();
}

void loop() {
  uint32_t nowUs = micros();

  if ((uint32_t)(nowUs - lastSampleUs) >= SAMPLE_PERIOD_US) {

    lastSampleUs += SAMPLE_PERIOD_US;
    sequenceNumber++;

    // Synthetic test values only
    float rpm = 3000.0f;
    float torqueNm = 20.0f;
    float flowLmin = 12.0f;
    float tempInC = 22.0f;
    float tempOutC = 28.0f;

    // No actual sensor or safety validation
    uint8_t dataValid = 0;

    Serial.print("DYNO_TEST,");
    Serial.print(sequenceNumber);
    Serial.print(",");
    Serial.print(nowUs);
    Serial.print(",");
    Serial.print(rpm, 2);
    Serial.print(",");
    Serial.print(torqueNm, 2);
    Serial.print(",");
    Serial.print(flowLmin, 2);
    Serial.print(",");
    Serial.print(tempInC, 2);
    Serial.print(",");
    Serial.print(tempOutC, 2);
    Serial.print(",");
    Serial.println(dataValid);
  }
}
