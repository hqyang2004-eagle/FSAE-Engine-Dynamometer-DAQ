function outputs = DynoForge_Test_Summary()
% DynoForge Step 10.13 - OFFLINE test summary from Step 10.12 CSV.
% Does not run Simulink, change the model, or access hardware.
    baseDir = fileparts(mfilename('fullpath'));
    inputFile = fullfile(baseDir,'Results','Step_10_12','DynoForge_Offline_Demo_Data.csv');
    outputDir = fullfile(baseDir,'Results','Step_10_13');
    assert(isfile(inputFile),'DynoForge:MissingCSV', ...
        'Step 10.12 CSV missing: %s. Complete Step 10.12 first.',inputFile);
    T = readtable(inputFile);
    required = {'Time_s','Force_N','RPM_rpm','Torque_Nm', ...
        'AngularVelocity_rad_s','Power_kW','TempIn_degC','TempOut_degC', ...
        'Flow_Demo_L_min','AlarmLevel_Demo','TestState_Demo', ...
        'Calibration_Confirmed','Flow_Calibrated','Data_Source'};
    assert(isequal(T.Properties.VariableNames,required), ...
        'DynoForge:Columns','CSV schema does not match Step 10.12.');
    assert(height(T)==501 && width(T)==14,'DynoForge:Size','Unexpected CSV dimensions.');
    t=T.Time_s;
    assert(all(isfinite(T{:,1:13}),'all'),'DynoForge:Nonfinite','CSV contains NaN/Inf.');
    assert(all(diff(t)>0) && all(abs(diff(t)-0.02)<1e-9), ...
        'DynoForge:Time','Invalid time order or sample interval.');
    assert(all(strcmp(string(T.Data_Source),'OFFLINE_SYNTHETIC')), ...
        'DynoForge:Source','Source must be OFFLINE_SYNTHETIC.');
    assert(all(T.Calibration_Confirmed==0) && all(T.Flow_Calibrated==0), ...
        'DynoForge:Calibration','CSV must not claim physical calibration.');
    assert(all(T.RPM_rpm>=0) && all(T.Force_N>=0), ...
        'DynoForge:Range','Negative RPM/force in source.');
    assert(all(abs(T.Torque_Nm-T.Force_N*0.3048)<1e-8), ...
        'DynoForge:Torque','Torque calculation mismatch.');
    assert(all(abs(T.AngularVelocity_rad_s-T.RPM_rpm*2*pi/60)<1e-8), ...
        'DynoForge:Omega','Angular velocity mismatch.');
    assert(all(abs(T.Power_kW-T.Torque_Nm.*T.AngularVelocity_rad_s/1000)<1e-8), ...
        'DynoForge:Power','Power calculation mismatch.');

    if ~isfolder(outputDir), mkdir(outputDir); end
    summaryFile=fullfile(outputDir,'DynoForge_Offline_Test_Summary.csv');
    figureFile=fullfile(outputDir,'DynoForge_Offline_Test_Curves.png');
    assert(~isfile(summaryFile) && ~isfile(figureFile), ...
        'DynoForge:OutputExists', ...
        'Step 10.13 outputs already exist. Move/rename them before rerunning.');

    [maxRPM,iR]=max(T.RPM_rpm);
    [maxTorque,iT]=max(T.Torque_Nm);
    [maxPower,iP]=max(T.Power_kW);
    metrics={'Sample_Count';'Duration_s';'Sampling_Rate_Hz'; ...
        'Peak_RPM_rpm';'Peak_RPM_Time_s';'Peak_Torque_Nm'; ...
        'Peak_Torque_Time_s';'Peak_Power_kW';'Peak_Power_Time_s'};
    values=[height(T);t(end)-t(1);1/median(diff(t)); ...
        maxRPM;t(iR);maxTorque;t(iT);maxPower;t(iP)];
    S=table(metrics,values,'VariableNames',{'Metric','Value'});
    writetable(S,summaryFile);

    fig=figure('Visible','off','Color','w','Position',[100 100 1000 900]);
    try
        subplot(3,1,1);
        plot(t,T.RPM_rpm,'LineWidth',1.5); grid on;
        ylabel('RPM (rpm)'); title('DynoForge | OFFLINE SYNTHETIC DATA (NOT MEASURED)');
        subplot(3,1,2);
        plot(t,T.Torque_Nm,'LineWidth',1.5); grid on;
        ylabel('Torque (N m)');
        subplot(3,1,3);
        plot(t,T.Power_kW,'LineWidth',1.5); grid on;
        ylabel('Power (kW)'); xlabel('Time (s)');
        print(fig,figureFile,'-dpng','-r150');
    catch ME
        if isgraphics(fig),close(fig);end
        rethrow(ME);
    end
    if isgraphics(fig),close(fig);end

    outputs=struct('InputCSV',inputFile,'SummaryCSV',summaryFile, ...
        'PlotPNG',figureFile,'Summary',S);
    fprintf('\n===== STEP 10.13 SUMMARY GENERATED =====\n');
    fprintf('PASS | Input validated: %s\n',inputFile);
    fprintf('PASS | Summary CSV: %s\n',summaryFile);
    fprintf('PASS | Plot PNG: %s\n',figureFile);
    fprintf('Peak RPM: %.3f rpm at %.2f s\n',maxRPM,t(iR));
    fprintf('Peak Torque: %.3f N*m at %.2f s\n',maxTorque,t(iT));
    fprintf('Peak Power: %.3f kW at %.2f s\n',maxPower,t(iP));
    fprintf('Source: OFFLINE_SYNTHETIC | Physical calibration: NOT VERIFIED\n');
    fprintf('Simulink/hardware: NOT TESTED\n');
    fprintf('=========================================\n');
end
