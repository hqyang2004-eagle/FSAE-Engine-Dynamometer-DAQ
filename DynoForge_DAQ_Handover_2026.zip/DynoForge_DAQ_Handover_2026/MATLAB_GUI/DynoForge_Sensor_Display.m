function app = DynoForge_Sensor_Display()
% DynoForge Step 10.6 - Offline sensor display prototype.
% DEMONSTRATION DATA ONLY. No Simulink/hardware access.

names = {'FORCE','ENGINE RPM','INLET TEMP','OUTLET TEMP', ...
         'WATER FLOW','PRESSURE','TORQUE','POWER'};
units = {'N','rpm','degC','degC','L/min','psi','N*m','kW'};
% Demonstration values only; NOT physical measurements.
demo = [120, 3500, 22.5, 29.1, 15.2, 32.0, 36.58, 13.41];
limits = [0 981; 0 11000; -50 200; -50 200; 0 inf; 0 100; 0 inf; 0 inf];

fig = uifigure('Name','DynoForge | Step 10.6 Sensor Display', ...
    'Position',[100 100 1100 650],'Color',[0.08 0.10 0.14]);
root = uigridlayout(fig,[4 1]);
root.RowHeight = {55,55,'1x',130};
root.Padding = [18 16 18 16];
root.RowSpacing = 10;
root.BackgroundColor = [0.08 0.10 0.14];

header = uilabel(root,'Text','DYNOFORGE | SENSOR DATA DISPLAY', ...
    'FontSize',22,'FontWeight','bold','FontColor',[0.95 0.97 1]);
header.Layout.Row = 1;

bar = uigridlayout(root,[1 4]);
bar.Layout.Row = 2;
bar.ColumnWidth = {'1x','1x','1x','1x'};
bar.BackgroundColor = [0.08 0.10 0.14];
loadBtn = uibutton(bar,'Text','LOAD DEMO VALUES','ButtonPushedFcn',@loadDemo);
zeroBtn = uibutton(bar,'Text','ZERO VALUES (DEMO)','ButtonPushedFcn',@zeroDemo);
badBtn = uibutton(bar,'Text','TEST INVALID INPUT','ButtonPushedFcn',@invalidDemo);
clearBtn = uibutton(bar,'Text','CLEAR / UNKNOWN','ButtonPushedFcn',@clearDemo);

cards = uigridlayout(root,[2 4]);
cards.Layout.Row = 3;
cards.RowHeight = {'1x','1x'};
cards.ColumnWidth = {'1x','1x','1x','1x'};
cards.BackgroundColor = [0.08 0.10 0.14];
readouts = cell(1,8);
statuses = cell(1,8);
for k = 1:8
    panel = uipanel(cards,'Title',names{k},'FontWeight','bold', ...
        'ForegroundColor',[0.86 0.91 0.98], ...
        'BackgroundColor',[0.13 0.16 0.21]);
    panel.Layout.Row = ceil(k/4);
    panel.Layout.Column = mod(k-1,4)+1;
    layout = uigridlayout(panel,[3 1]);
    layout.RowHeight = {'1x',25,24};
    layout.BackgroundColor = [0.13 0.16 0.21];
    readouts{k} = uilabel(layout,'Text','--','FontSize',27, ...
        'FontWeight','bold','FontColor',[0.93 0.96 1], ...
        'HorizontalAlignment','center');
    uilabel(layout,'Text',units{k},'FontColor',[0.67 0.77 0.87], ...
        'HorizontalAlignment','center');
    statuses{k} = uilabel(layout,'Text','UNKNOWN', ...
        'FontColor',[1 0.74 0.29], ...
        'HorizontalAlignment','center','FontWeight','bold');
end

bottom = uigridlayout(root,[2 1]);
bottom.Layout.Row = 4;
bottom.RowHeight = {24,'1x'};
bottom.BackgroundColor = [0.08 0.10 0.14];
notice = uilabel(bottom,'Text', ...
    'OFFLINE DEMO | NO LIVE SENSOR DATA | NOT FOR ENGINE CONTROL', ...
    'FontWeight','bold','FontColor',[1 0.74 0.29]);
logBox = uitextarea(bottom,'Editable','off', ...
    'Value',{'[INFO] Step 10.6 initialized'; ...
    '[SAFE] No Simulink commands or hardware access'; ...
    '[INFO] All channels UNKNOWN until demonstration data is loaded'});

counts = zeros(1,4);
setappdata(fig,'DynoForgeSensorReport',@report);
app = fig;

fprintf('\n===== STEP 10.6 SENSOR DISPLAY =====\n');
fprintf('PASS | Sensor display window created\n');
fprintf('PASS | 8 channels initialized as UNKNOWN\n');
fprintf('PASS | Offline-only callbacks installed\n');
fprintf('Run DynoForge_Sensor_Test_Report after testing buttons.\n');
fprintf('====================================\n');

    function displayValues(values, mode)
        for j = 1:8
            v = values(j);
            if ~isfinite(v) || v < limits(j,1) || v > limits(j,2)
                readouts{j}.Text = '--';
                statuses{j}.Text = 'INVALID DEMO';
                statuses{j}.FontColor = [1 0.32 0.32];
            else
                if j == 2
                    readouts{j}.Text = sprintf('%.0f',v);
                else
                    readouts{j}.Text = sprintf('%.2f',v);
                end
                statuses{j}.Text = mode;
                statuses{j}.FontColor = [0.40 0.85 0.67];
            end
        end
    end

    function addLog(msg)
        logBox.Value = [logBox.Value; {msg}];
    end

    function loadDemo(~,~)
        counts(1) = counts(1)+1;
        displayValues(demo,'DEMO ONLY');
        addLog('[DEMO] Sample sensor readings displayed; not measurements');
    end

    function zeroDemo(~,~)
        counts(2) = counts(2)+1;
        displayValues(zeros(1,8),'DEMO ZERO');
        addLog('[DEMO] Zero-valued sensor display test');
    end

    function invalidDemo(~,~)
        counts(3) = counts(3)+1;
        invalid = demo;
        invalid(2) = NaN;
        invalid(6) = 150;
        displayValues(invalid,'DEMO ONLY');
        addLog('[DEMO] Invalid RPM and out-of-range pressure flagged');
    end

    function clearDemo(~,~)
        counts(4) = counts(4)+1;
        for j = 1:8
            readouts{j}.Text = '--';
            statuses{j}.Text = 'UNKNOWN';
            statuses{j}.FontColor = [1 0.74 0.29];
        end
        addLog('[INFO] Display reset to UNKNOWN');
    end

    function report()
        fprintf('\n===== STEP 10.6 OFFLINE VERIFICATION =====\n');
        labels = {'LOAD DEMO VALUES','ZERO VALUES','TEST INVALID INPUT','CLEAR / UNKNOWN'};
        for j = 1:4
            if counts(j)>0
                fprintf('PASS | %s: %d test(s)\n',labels{j},counts(j));
            else
                fprintf('NOT TESTED | %s\n',labels{j});
            end
        end
        if all(counts>0)
            fprintf('STEP 10.6 OFFLINE DISPLAY TEST PASSED\n');
        else
            fprintf('STEP 10.6 INCOMPLETE: test all four buttons\n');
        end
        fprintf('Live Simulink and hardware data: NOT TESTED\n');
        fprintf('==========================================\n');
    end
end
