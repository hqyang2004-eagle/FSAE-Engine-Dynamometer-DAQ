function DynoForge_Realtime_Plot_Test_Report()
% Step 10.11 report: reads the open offline plotting window.
figs = findall(groot,'Type','figure');
for k = 1:numel(figs)
    if isappdata(figs(k),'DynoForgeStep1011Report')
        fn = getappdata(figs(k),'DynoForgeStep1011Report');
        fn();
        return;
    end
end
fprintf('STEP 10.11 NOT TESTED: Open DynoForge_Realtime_Plot first.\n');
end
