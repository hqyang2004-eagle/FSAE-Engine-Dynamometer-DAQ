﻿DynoForge DAQ - Handover Package
October 2026

CONTENTS
Simulink: Main ME486C DAQ model
MATLAB_GUI: MATLAB dashboards, launcher, LIVE30 programs
Arduino_Firmware: Compiled firmware files
Test_Results: Development and test outputs
Documentation: Hardware source files and file manifest

VERIFIED
Simulink model compiled and deployed to Arduino UNO R4 Minima.
External Mode connected, executed, and stopped successfully.
MATLAB workspace time-series data was inspected.

NOT YET VERIFIED
Real sensor acquisition and calibration.
LIVE30 communication with the deployed Simulink firmware.
Automatic dashboard startup on another computer.

IMPORTANT
Some test data is synthetic or from offline tests.
Do not treat archived measurements as validated engine data.
Review configuration, dependencies, COM port and safety interlocks before operation.
Do not operate the engine until hardware and safety validation are complete.
