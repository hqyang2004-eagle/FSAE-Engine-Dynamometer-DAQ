function report = DynoForge_Unified_Dashboard_Interactive_Test_Report()
% Step 10.14C-3: desktop simulation + GUI refresh/clear/multi-run tests.
% No Arduino deployment, no model modification, no operator command writes.
fprintf('\n===== STEP 10.14C-3 VERIFICATION =====\n');
model='ME486C_Dyno_DAQ_Quality_Development';
load_system(model);
assert(strcmp(get_param(model,'SimulationStatus'),'stopped'));
assert(strcmp(get_param(model,'SimulationMode'),'normal'));
cmds={'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
for k=1:3
    assert(strcmp(strtrim(get_param([model '/' cmds{k}],'Value')),'0'));
end
fprintf('PASS | COMMAND_PRECHECK\n');
in=Simulink.SimulationInput(model);
in=in.setModelParameter('StopTime','0.20','ReturnWorkspaceOutputs','on');
out=sim(in);
D=DynoForge_Data_Adapter(out);
assert(D.LogCount==39);
fprintf('PASS | REAL_SIMULATION_39_LOGS\n');
app=DynoForge_Unified_Dashboard_Interactive(D);
assert(isvalid(app.Figure) && numel(app.MetricLabels)==9 && ...
    numel(app.StatusLabels)==12 && numel(app.Axes)==3);
fprintf('PASS | DASHBOARD_LAYOUT\n');
app.Refresh();
s=app.GetState();
assert(s.RefreshCount==1 && ~s.DisplayCleared);
fprintf('PASS | REFRESH_EXISTING_WINDOW\n');
app.Clear();
s=app.GetState();
assert(s.DisplayCleared && strcmp(app.MetricLabels(1).Text,'--'));
fprintf('PASS | CLEAR_DISPLAY_ONLY\n');
app.SetDashboard(D);
s=app.GetState();
assert(~s.DisplayCleared && ~strcmp(app.MetricLabels(1).Text,'--'));
fprintf('PASS | RESTORE_SNAPSHOT\n');
% A second actual desktop simulation verifies multiple runs without GUI recreation.
out2=sim(in);
D2=DynoForge_Data_Adapter(out2);
app.SetDashboard(D2);
state2=app.GetState();
assert(isvalid(app.Figure) && D2.LogCount==39 && ...
    isequal(state2.Dashboard.LogNames,D.LogNames));
fprintf('PASS | SECOND_SIMULATION_SAME_WINDOW\n');
% Reject incomplete data without changing the current valid display.
bad=D2;bad.Signals=rmfield(bad.Signals,'ENG_RPM');
rejected=false;
try
    app.SetDashboard(bad);
catch
    rejected=true;
end
state3=app.GetState();
assert(rejected && isfield(state3.Dashboard.Signals,'ENG_RPM'));
fprintf('PASS | INVALID_SNAPSHOT_REJECTED\n');
report=struct('Passed',true,'DashboardApp',app,'LatestDashboard',D2, ...
    'TestCount',8);
fprintf('\nSTEP 10.14C-3 MULTI-RUN DASHBOARD TEST PASSED\n');
fprintf('RUN SIMULATION button: MANUAL CLICK TEST PENDING\n');
fprintf('Hardware/calibration: NOT VERIFIED\n');
fprintf('Live streaming: NOT TESTED\n');
fprintf('==========================================\n');
end
