
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <math.h>

#include <SparkFun_Qwiic_Scale_NAU7802_Arduino_Library.h>
#include <Adafruit_MAX31865.h>

// =====================================================
// DynoForge Integrated DAQ Firmware V2
// Board: Arduino UNO R4 Minima
//
// Development firmware only.
// Physical sensors and safety system NOT verified.
//
// LIVE-30 protocol:
// AA 55 + RPM(2) + Torque(2) + Temp(2)
//       + Flow(2) + Checksum(1)
//
// Total: 11 bytes
// =====================================================

// =====================================================
// 1. Operating Mode
// =====================================================

// true  = LIVE-30 binary protocol
// false = Development CSV output
constexpr bool LIVE30_BINARY_MODE = true;

// =====================================================
// 2. Hardware Pins
// =====================================================

constexpr uint8_t RPM_PIN = 2;
constexpr uint8_t FLOW_PIN = 3;

constexpr uint8_t RTD_IN_CS = 10;
constexpr uint8_t RTD_OUT_CS = 9;

// =====================================================
// 3. Sampling and Communication
// =====================================================

constexpr uint32_t BAUD_RATE = 115200;
constexpr uint32_t SAMPLE_PERIOD_US = 20000UL;

constexpr uint32_t RPM_PULSES_PER_REV = 10;

// =====================================================
// 4. Mechanical Parameters
// =====================================================

// 12.000 inches = 0.3048 meters
constexpr float TORQUE_ARM_M = 0.3048f;

// =====================================================
// 5. Temperature Parameters
// =====================================================

constexpr float RTD_RNOMINAL = 100.0f;
constexpr float RTD_RREF = 430.0f;

// =====================================================
// 6. Calibration Parameters
// =====================================================

// Must be replaced after actual calibration.
// NAN means calibration has not been performed.

constexpr float FLOW_K_PULSES_PER_LITER = NAN;

constexpr float LOADCELL_ZERO_COUNT = NAN;

constexpr float LOADCELL_N_PER_COUNT = NAN;

// =====================================================
// 7. Preliminary Monitoring Thresholds
// =====================================================

// These are development thresholds, NOT a validated
// engine protection system.

constexpr float MAX_RPM = 11000.0f;
constexpr float MAX_TEMP_C = 95.0f;

constexpr uint32_t RPM_TIMEOUT_US = 500000UL;
constexpr uint32_t FLOW_TIMEOUT_US = 500000UL;

// =====================================================
// 8. Sensor Objects
// =====================================================

NAU7802 loadCell;

Adafruit_MAX31865 rtdIn(RTD_IN_CS);
Adafruit_MAX31865 rtdOut(RTD_OUT_CS);

bool loadCellOnline = false;
bool rtdInInitialized = false;
bool rtdOutInitialized = false;

// =====================================================
// 9. Interrupt Variables
// =====================================================

volatile uint32_t rpmPulseCount = 0;
volatile uint32_t flowPulseCount = 0;

volatile uint32_t rpmLastEdgeUs = 0;
volatile uint32_t rpmPeriodUs = 0;

volatile uint32_t flowLastEdgeUs = 0;

// =====================================================
// 10. Runtime Variables
// =====================================================

uint32_t previousRpmCount = 0;
uint32_t previousFlowCount = 0;

uint32_t previousSampleUs = 0;
uint32_t sequenceNumber = 0;

// =====================================================
// 11. Interrupt Service Routines
// =====================================================

void rpmISR() {

  uint32_t now = micros();

  if (rpmLastEdgeUs != 0) {
    rpmPeriodUs = now - rpmLastEdgeUs;
  }

  rpmLastEdgeUs = now;

  ++rpmPulseCount;
}

void flowISR() {

  flowLastEdgeUs = micros();

  ++flowPulseCount;
}

// =====================================================
// 12. Utility Functions
// =====================================================

void printFinite(float value, uint8_t digits = 3) {

  if (isfinite(value)) {
    Serial.print(value, digits);
  } else {
    Serial.print("NaN");
  }
}

// =====================================================
// 13. LIVE-30 Binary Frame Encoder
// =====================================================

// Frame byte positions:
//
// [0]  0xAA
// [1]  0x55
// [2]  RPM high
// [3]  RPM low
// [4]  Torque high
// [5]  Torque low
// [6]  Temperature high
// [7]  Temperature low
// [8]  Flow high
// [9]  Flow low
// [10] Checksum
//
// MATLAB decoding:
// RPM    = uint16
// Torque = uint16 / 10
// Temp   = int16  / 10
// Flow   = uint16 / 10

bool sendLIVE30Frame(
  float rpm,
  float torqueNm,
  float temperatureC,
  float flowLmin
) {

  // Reject invalid values.
  if (!isfinite(rpm) ||
      !isfinite(torqueNm) ||
      !isfinite(temperatureC) ||
      !isfinite(flowLmin)) {
    return false;
  }

  // Reject values outside protocol ranges.
  if (rpm < 0.0f || rpm > 65535.0f ||
      torqueNm < 0.0f || torqueNm > 6553.5f ||
      temperatureC < -3276.8f ||
      temperatureC > 3276.7f ||
      flowLmin < 0.0f || flowLmin > 6553.5f) {
    return false;
  }

  uint16_t rpmRaw =
    (uint16_t)roundf(rpm);

  uint16_t torqueRaw =
    (uint16_t)roundf(torqueNm * 10.0f);

  int16_t tempSigned =
    (int16_t)roundf(temperatureC * 10.0f);

  uint16_t tempRaw =
    (uint16_t)tempSigned;

  uint16_t flowRaw =
    (uint16_t)roundf(flowLmin * 10.0f);

  uint8_t frame[11];

  frame[0] = 0xAA;
  frame[1] = 0x55;

  frame[2] = (uint8_t)(rpmRaw >> 8);
  frame[3] = (uint8_t)(rpmRaw & 0xFF);

  frame[4] = (uint8_t)(torqueRaw >> 8);
  frame[5] = (uint8_t)(torqueRaw & 0xFF);

  frame[6] = (uint8_t)(tempRaw >> 8);
  frame[7] = (uint8_t)(tempRaw & 0xFF);

  frame[8] = (uint8_t)(flowRaw >> 8);
  frame[9] = (uint8_t)(flowRaw & 0xFF);

  uint16_t checksum = 0;

  for (uint8_t i = 2; i <= 9; ++i) {
    checksum += frame[i];
  }

  frame[10] = (uint8_t)(checksum & 0xFF);

  // Avoid knowingly sending a partial frame.
  if (Serial.availableForWrite() < sizeof(frame)) {
    return false;
  }

  return Serial.write(frame, sizeof(frame)) == sizeof(frame);
}

// =====================================================
// 14. Setup
// =====================================================

void setup() {

  Serial.begin(BAUD_RATE);

  // Input circuitry must be verified before wiring.
  pinMode(RPM_PIN, INPUT);
  pinMode(FLOW_PIN, INPUT);

  Wire.begin();
  SPI.begin();

  // -----------------------------------------------
  // NAU7802 Initialization
  // -----------------------------------------------

  loadCellOnline = loadCell.begin(Wire);

  if (loadCellOnline) {

    loadCell.setGain(NAU7802_GAIN_128);

    loadCell.setSampleRate(NAU7802_SPS_80);

    loadCell.calibrateAFE();
  }

  // -----------------------------------------------
  // MAX31865 Initialization
  // -----------------------------------------------

  rtdInInitialized =
    rtdIn.begin(MAX31865_3WIRE);

  rtdOutInitialized =
    rtdOut.begin(MAX31865_3WIRE);

  // -----------------------------------------------
  // Interrupt Configuration
  // -----------------------------------------------

  attachInterrupt(
    digitalPinToInterrupt(RPM_PIN),
    rpmISR,
    RISING
  );

  attachInterrupt(
    digitalPinToInterrupt(FLOW_PIN),
    flowISR,
    RISING
  );

  previousSampleUs = micros();

  // Never print text into LIVE-30 binary stream.
  if (!LIVE30_BINARY_MODE) {

    Serial.println(
      "# DynoForge V2 DEVELOPMENT MODE"
    );

    Serial.println(
      "# No physical sensor validation"
    );

    Serial.println(
      "# seq,time_us,rpm,flow_hz,flow_lmin,"
      "adc_raw,force_n,torque_nm,power_kw,hp,"
      "temp_in_c,temp_out_c,fault_mask"
    );
  }
}

// =====================================================
// 15. Main Loop
// =====================================================

void loop() {

  uint32_t nowUs = micros();

  uint32_t elapsedUs =
    nowUs - previousSampleUs;

  if (elapsedUs < SAMPLE_PERIOD_US) {
    return;
  }

  previousSampleUs = nowUs;

  ++sequenceNumber;

  // =================================================
  // 15.1 Read Interrupt Counters Atomically
  // =================================================

  uint32_t currentRpmCount;
  uint32_t currentFlowCount;

  uint32_t lastRpmEdge;
  uint32_t lastFlowEdge;
  uint32_t lastRpmPeriod;

  noInterrupts();

  currentRpmCount = rpmPulseCount;
  currentFlowCount = flowPulseCount;

  lastRpmEdge = rpmLastEdgeUs;
  lastFlowEdge = flowLastEdgeUs;

  lastRpmPeriod = rpmPeriodUs;

  interrupts();

  uint32_t rpmDelta =
    currentRpmCount - previousRpmCount;

  uint32_t flowDelta =
    currentFlowCount - previousFlowCount;

  previousRpmCount = currentRpmCount;
  previousFlowCount = currentFlowCount;

  // =================================================
  // 15.2 RPM Calculation
  // =================================================

  bool rpmFresh =
    lastRpmEdge != 0 &&
    (uint32_t)(nowUs - lastRpmEdge)
      <= RPM_TIMEOUT_US;

  float rpm = 0.0f;

  if (rpmFresh) {

    if (rpmDelta >= 2) {

      rpm =
        (float)rpmDelta *
        60000000.0f /
        (
          (float)RPM_PULSES_PER_REV *
          (float)elapsedUs
        );

    } else if (lastRpmPeriod > 0) {

      rpm =
        60000000.0f /
        (
          (float)RPM_PULSES_PER_REV *
          (float)lastRpmPeriod
        );
    }
  }

  bool rpmValid =
    rpmFresh &&
    rpm > 0.0f &&
    rpm <= MAX_RPM;

  // =================================================
  // 15.3 Flow Calculation
  // =================================================

  bool flowFresh =
    lastFlowEdge != 0 &&
    (uint32_t)(nowUs - lastFlowEdge)
      <= FLOW_TIMEOUT_US;

  float flowHz =
    (float)flowDelta *
    1000000.0f /
    (float)elapsedUs;

  bool flowCalibrated =
    isfinite(FLOW_K_PULSES_PER_LITER) &&
    FLOW_K_PULSES_PER_LITER > 0.0f;

  float flowLmin = NAN;

  if (flowCalibrated) {

    flowLmin =
      60.0f * flowHz /
      FLOW_K_PULSES_PER_LITER;
  }

  bool flowValid =
    flowFresh &&
    flowCalibrated &&
    isfinite(flowLmin);

  // =================================================
  // 15.4 NAU7802 Load Cell
  // =================================================

  int32_t adcRaw = 0;

  bool loadSampleAvailable = false;

  if (loadCellOnline && loadCell.available()) {

    adcRaw = loadCell.getReading();

    loadSampleAvailable = true;
  }

  bool loadCalibrated =
    isfinite(LOADCELL_ZERO_COUNT) &&
    isfinite(LOADCELL_N_PER_COUNT);

  bool loadValid =
    loadSampleAvailable &&
    loadCalibrated;

  float forceN = NAN;

  if (loadValid) {

    forceN =
      ((float)adcRaw - LOADCELL_ZERO_COUNT) *
      LOADCELL_N_PER_COUNT;
  }

  // =================================================
  // 15.5 Engineering Calculations
  // =================================================

  float torqueNm = NAN;
  float powerKW = NAN;
  float hp = NAN;

  if (loadValid) {

    torqueNm =
      forceN * TORQUE_ARM_M;
  }

  if (loadValid && rpmValid) {

    powerKW =
      torqueNm *
      rpm *
      2.0f *
      PI /
      60.0f /
      1000.0f;

    hp =
      powerKW * 1000.0f / 745.7f;
  }

  // =================================================
  // 15.6 MAX31865 Temperature
  // =================================================

  float tempInC = NAN;
  float tempOutC = NAN;

  bool tempInValid = false;
  bool tempOutValid = false;

  if (rtdInInitialized) {

    // Clear previous latched fault before new read.
    rtdIn.clearFault();

    tempInC = rtdIn.temperature(
      RTD_RNOMINAL,
      RTD_RREF
    );

    uint8_t faultIn = rtdIn.readFault();

    tempInValid =
      faultIn == 0 &&
      isfinite(tempInC) &&
      tempInC > -200.0f &&
      tempInC < 850.0f;
  }

  if (rtdOutInitialized) {

    rtdOut.clearFault();

    tempOutC = rtdOut.temperature(
      RTD_RNOMINAL,
      RTD_RREF
    );

    uint8_t faultOut = rtdOut.readFault();

    tempOutValid =
      faultOut == 0 &&
      isfinite(tempOutC) &&
      tempOutC > -200.0f &&
      tempOutC < 850.0f;
  }

  // =================================================
  // 15.7 Informational Fault Flags
  // =================================================

  // These flags are not a physical safety shutdown.

  uint32_t faultMask = 0;

  if (!rpmValid) {
    faultMask |= (1UL << 0);
  }

  if (!flowValid) {
    faultMask |= (1UL << 1);
  }

  if (!loadValid) {
    faultMask |= (1UL << 2);
  }

  if (!tempInValid) {
    faultMask |= (1UL << 3);
  }

  if (!tempOutValid) {
    faultMask |= (1UL << 4);
  }

  if (rpm > MAX_RPM) {
    faultMask |= (1UL << 5);
  }

  if (
    (tempInValid && tempInC > MAX_TEMP_C) ||
    (tempOutValid && tempOutC > MAX_TEMP_C)
  ) {
    faultMask |= (1UL << 6);
  }

  // =================================================
  // 15.8 Serial Output
  // =================================================

  if (LIVE30_BINARY_MODE) {

    // LIVE-30 supports one temperature channel.
    // This implementation uses outlet temperature.
    //
    // Never send a measurement frame with
    // uncalibrated or invalid required channels.

    bool readyToTransmit =
      rpmValid &&
      flowValid &&
      loadValid &&
      tempOutValid;

    if (readyToTransmit) {

      sendLIVE30Frame(
        rpm,
        torqueNm,
        tempOutC,
        flowLmin
      );
    }

  } else {

    // Development CSV diagnostics

    Serial.print("DYNO_DEV,");

    Serial.print(sequenceNumber);

    Serial.print(',');
    Serial.print(nowUs);

    Serial.print(',');
    printFinite(rpm, 2);

    Serial.print(',');
    printFinite(flowHz, 2);

    Serial.print(',');
    printFinite(flowLmin, 3);

    Serial.print(',');
    Serial.print(adcRaw);

    Serial.print(',');
    printFinite(forceN, 3);

    Serial.print(',');
    printFinite(torqueNm, 3);

    Serial.print(',');
    printFinite(powerKW, 3);

    Serial.print(',');
    printFinite(hp, 3);

    Serial.print(',');
    printFinite(tempInC, 2);

    Serial.print(',');
    printFinite(tempOutC, 2);

    Serial.print(',');
    Serial.println(faultMask);
  }
}
