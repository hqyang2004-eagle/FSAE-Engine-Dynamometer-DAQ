function dashboard = DynoForge_Data_Adapter(simOut)
% DynoForge Step 10.14C-1: Convert 39 real Simulink logs into a
% validated, read-only dashboard data structure.
% No simulation, model writes, or hardware access.

if ~isa(simOut,'Simulink.SimulationOutput')
    error('DynoForge:InvalidInput','Input must be Simulink.SimulationOutput.');
end

spec = { ...
 'ALM_Active','ALM_Calibration','ALM_Code','ALM_Level','ALM_Sensor','ALM_Shutdown', ...
 'ENG_Cooling_Power_kW','ENG_Delta_T_C','ENG_Flow_Lmin','ENG_Force_N', ...
 'ENG_Power_kW','ENG_RPM','ENG_Temp_In_C','ENG_Temp_Out_C','ENG_Torque_Nm', ...
 'SQ_All_Sensors_OK','SQ_Flow_Quality_OK','SQ_Force_Quality_OK', ...
 'SQ_Quality_Fault_Code','SQ_Quality_Warning','SQ_RPM_Quality_OK', ...
 'SQ_Temp_In_Quality_OK','SQ_Temp_Out_Quality_OK', ...
 'SEQ_Active','SEQ_Fault_Latched','SEQ_Permit','SEQ_Ready', ...
 'SEQ_Start_Accepted','SEQ_State_Changed','SEQ_State','SEQ_Stop_Active', ...
 'CAL_All_Params_Valid','CAL_Calibration_Complete','CAL_Calibration_Fault_Code', ...
 'CAL_Flow_Param_OK','CAL_LoadCell_Param_OK','CAL_RPM_Param_OK', ...
 'CAL_Temp_In_Param_OK','CAL_Temp_Out_Param_OK'};

available = simOut.who;
missing = spec(~ismember(spec,available));
if ~isempty(missing)
    error('DynoForge:MissingLogs','Missing log(s): %s',strjoin(missing,', '));
end

dashboard = struct();
dashboard.Source = 'SIMULINK_DESKTOP_SIMULATION';
dashboard.HardwareVerified = false;
dashboard.SensorCalibrationVerified = false;
dashboard.LogCount = numel(spec);
dashboard.LogNames = spec;
dashboard.Signals = struct();
dashboard.Groups = struct('Engineering',{{}},'Quality',{{}}, ...
    'Calibration',{{}},'Alarm',{{}},'Sequence',{{}});

for k = 1:numel(spec)
    name = spec{k};
    ts = simOut.get(name);
    if ~isa(ts,'timeseries')
        error('DynoForge:NotTimeseries','%s is not a timeseries.',name);
    end
    t = double(ts.Time(:));
    values = ts.Data;
    if ~(isnumeric(values) || islogical(values)) || ~isreal(values)
        error('DynoForge:InvalidData','%s must contain real numeric/logical data.',name);
    end
    if isempty(t) || any(~isfinite(t)) || any(diff(t)<=0)
        error('DynoForge:InvalidTime','%s has invalid timestamps.',name);
    end
    if numel(values) ~= numel(t)
        error('DynoForge:InvalidShape','%s must contain one scalar per timestamp.',name);
    end
    values = double(values(:));
    if any(~isfinite(values))
        error('DynoForge:NonfiniteData','%s contains NaN/Inf.',name);
    end
    dashboard.Signals.(name) = struct('Time_s',t,'Value',values, ...
        'SampleCount',numel(t));
    if strncmp(name,'ENG_',4)
        group='Engineering';
    elseif strncmp(name,'SQ_',3)
        group='Quality';
    elseif strncmp(name,'CAL_',4)
        group='Calibration';
    elseif strncmp(name,'ALM_',4)
        group='Alarm';
    else
        group='Sequence';
    end
    dashboard.Groups.(group){end+1} = name;
end

% The final observed calibration state is informational only. It never
% authorizes a claim that physical sensor calibration has been verified.
cal = dashboard.Signals.CAL_Calibration_Complete.Value;
dashboard.ModelCalibrationCompleteAtEnd = logical(cal(end)~=0);
dashboard.TimeAlignmentAssumed = false;
end
