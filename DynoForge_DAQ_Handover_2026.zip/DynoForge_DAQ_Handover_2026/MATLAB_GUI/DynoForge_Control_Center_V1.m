function app = DynoForge_Control_Center_V1(projectDir)
% DynoForge Control Center V1 - read-only desktop report explorer.
% Does not run Simulink, write to the model, or access hardware.
if nargin<1 || isempty(projectDir), projectDir='C:\DynoForge_Test'; end
assert(isfolder(projectDir),'Project folder not found: %s',projectDir);
resultsRoot=fullfile(projectDir,'Results');
fig=uifigure('Name','DynoForge Control Center | V1.0 | OFFLINE', ...
    'Position',[80 60 1320 780],'Color',[0.96 0.97 0.98]);
root=uigridlayout(fig,[3 2]);
root.RowHeight={65,'1x',36};root.ColumnWidth={215,'1x'};
root.Padding=[12 12 12 12];root.RowSpacing=8;root.ColumnSpacing=10;
header=uipanel(root,'BorderType','none','BackgroundColor',[0.12 0.18 0.26]);
header.Layout.Row=1;header.Layout.Column=[1 2];
hg=uigridlayout(header,[1 2]);hg.ColumnWidth={'1x',360};hg.Padding=[15 8 15 8];
uilabel(hg,'Text','DynoForge  |  CONTROL CENTER','FontSize',22, ...
    'FontWeight','bold','FontColor',[1 1 1]);
uilabel(hg,'Text','DESKTOP SIMULATION  |  HARDWARE NOT VERIFIED', ...
    'FontColor',[1 0.8 0.42],'HorizontalAlignment','right');
side=uipanel(root,'Title','Navigation');side.Layout.Row=2;side.Layout.Column=1;
nav=uigridlayout(side,[9 1]);nav.RowHeight=[repmat({43},1,8),{'1x'}];
nav.Padding=[7 10 7 10];nav.RowSpacing=6;
pageNames={'Overview','60-Plot Explorer','Engineering','Cooling System', ...
    'Safety & Alarms','Data & Reports','Diagnostics','Refresh Reports'};
buttons=gobjects(8,1);
for k=1:8
    buttons(k)=uibutton(nav,'push','Text',pageNames{k});
    buttons(k).ButtonPushedFcn=@(~,~) navigate(k);
end
uilabel(nav,'Text','READ ONLY / NO HARDWARE','FontColor',[0.7 0.3 0.1]);
content=uipanel(root,'Title','Overview');content.Layout.Row=2;content.Layout.Column=2;
footer=uipanel(root,'BorderType','none');footer.Layout.Row=3;footer.Layout.Column=[1 2];
fg=uigridlayout(footer,[1 2]);fg.ColumnWidth={'1x',170};fg.Padding=[8 1 8 1];
status=uilabel(fg,'Text','Initializing...','FontSize',11);
uilabel(fg,'Text','DynoForge V1.0 | OFFLINE','HorizontalAlignment','right');
reportDir='';plotFiles=struct('folder',{},'name',{});plotIndex=1;
app=struct('Figure',fig,'NavigationButtons',buttons, ...
    'GetState',@getState,'RefreshReports',@refreshReports,'ShowPage',@showPage);
refreshReports();navigate(1);

    function s=getState()
        s=struct('ReportFolder',reportDir,'PlotCount',numel(plotFiles), ...
            'CurrentPlotIndex',plotIndex,'HardwareVerified',false);
    end
    function showPage(name)
        idx=find(strcmpi(pageNames,name),1);
        assert(~isempty(idx),'Unknown page: %s',name);
        navigate(idx);
    end
    function refreshReports()
        reportDir='';plotFiles=struct('folder',{},'name',{});plotIndex=1;
        if ~isfolder(resultsRoot)
            status.Text='Results folder missing. No model or data modified.';return;
        end
        dirs=dir(fullfile(resultsRoot,'DynoForge_60Plots_*'));
        dirs=dirs([dirs.isdir]);
        if isempty(dirs)
            status.Text='No 60-plot report found. Generate the report first.';return;
        end
        [~,order]=sort([dirs.datenum],'descend');
        reportDir=fullfile(dirs(order(1)).folder,dirs(order(1)).name);
        subdirs={'02_Engineering_Plots','03_Cooling_Plots', ...
            '04_Safety_and_Faults','05_Data_Quality'};
        for j=1:numel(subdirs)
            d=dir(fullfile(reportDir,subdirs{j},'*.png'));
            for q=1:numel(d)
                plotFiles(end+1)=d(q); %#ok<AGROW>
            end
        end
        status.Text=sprintf('Report: %s | PNG plots found: %d | OFFLINE', ...
            dirs(order(1)).name,numel(plotFiles));
    end
    function clearContent()
        delete(content.Children);
    end
    function navigate(idx)
        if idx==8
            refreshReports();idx=1;
        end
        clearContent();content.Title=pageNames{idx};
        switch idx
            case 1
                g=uigridlayout(content,[7 1]);
                g.RowHeight={60,40,40,40,40,40,'1x'};
                uilabel(g,'Text','DynoForge Desktop Software Overview', ...
                    'FontSize',23,'FontWeight','bold');
                uilabel(g,'Text','Mode: OFFLINE / SIMULINK DESKTOP SIMULATION');
                uilabel(g,'Text','Validated baseline: 39 logged timeseries; 3 desktop runs passed.');
                uilabel(g,'Text',sprintf('Detected plot PNG files: %d',numel(plotFiles)));
                uilabel(g,'Text','No Arduino, sensors, calibration or physical safety testing performed.');
                uilabel(g,'Text','Use the left navigation to inspect saved plots and reports.');
                uilabel(g,'Text','V1 is a read-only report viewer. Simulation controls will be added after acceptance.');
            case 2
                plotExplorer();
            case {3,4,5}
                categoryFolders={'02_Engineering_Plots','03_Cooling_Plots','04_Safety_and_Faults'};
                category=categoryFolders{idx-2};
                list=dir(fullfile(reportDir,category,'*.png'));
                if isempty(list)
                    showMessage('No saved plots found for this category.');return;
                end
                showCategory(category,list);
            case 6
                showReports();
            case 7
                showDiagnostics();
        end
    end
    function showMessage(message)
        g=uigridlayout(content,[1 1]);
        uilabel(g,'Text',message,'FontSize',14);
    end
    function plotExplorer()
        if isempty(plotFiles)
            showMessage('No PNG files found. Check the Results report directory.');return;
        end
        g=uigridlayout(content,[3 1]);g.RowHeight={45,40,'1x'};
        top=uigridlayout(g,[1 3]);top.ColumnWidth={130,'1x',130};
        prev=uibutton(top,'push','Text','< Previous');
        options=arrayfun(@(x) x.name,plotFiles,'UniformOutput',false);
        pick=uidropdown(top,'Items',options,'Value',options{plotIndex});
        next=uibutton(top,'push','Text','Next >');
        info=uilabel(g,'Text','','FontSize',12);
        pic=uiimage(g,'ScaleMethod','fit');
        prev.ButtonPushedFcn=@(~,~) updatePlot(max(1,plotIndex-1));
        next.ButtonPushedFcn=@(~,~) updatePlot(min(numel(plotFiles),plotIndex+1));
        pick.ValueChangedFcn=@(~,~) updatePlot(find(strcmp(options,pick.Value),1));
        updatePlot(plotIndex);
        function updatePlot(i)
            if isempty(i),return;end
            plotIndex=i;pick.Value=options{i};
            file=fullfile(plotFiles(i).folder,plotFiles(i).name);
            pic.ImageSource=file;
            [~,group]=fileparts(plotFiles(i).folder);
            info.Text=sprintf('%d / %d | %s | %s',i,numel(plotFiles),group,plotFiles(i).name);
        end
    end
    function showCategory(category,list)
        g=uigridlayout(content,[2 1]);g.RowHeight={45,'1x'};
        choices={list.name};
        pick=uidropdown(g,'Items',choices,'Value',choices{1});
        pic=uiimage(g,'ScaleMethod','fit');
        pick.ValueChangedFcn=@(~,~) displaySelected();
        displaySelected();
        function displaySelected()
            pic.ImageSource=fullfile(reportDir,category,pick.Value);
        end
    end
    function showReports()
        g=uigridlayout(content,[5 1]);g.RowHeight={55,55,55,55,'1x'};
        uilabel(g,'Text','Latest saved report directory:','FontWeight','bold');
        uilabel(g,'Text',reportDir,'Interpreter','none');
        b=uibutton(g,'push','Text','Open Report Folder');
        b.ButtonPushedFcn=@(~,~) openFolder();
        uilabel(g,'Text','Inspect Plot_Manifest.csv for N/A/error entries.');
        uilabel(g,'Text','This viewer does not regenerate or overwrite reports.');
    end
    function openFolder()
        if isfolder(reportDir),winopen(reportDir);else,uialert(fig,'Report folder not found.','Missing Report');end
    end
    function showDiagnostics()
        g=uigridlayout(content,[6 1]);g.RowHeight={45,45,45,45,45,'1x'};
        uilabel(g,'Text','System Diagnostics','FontSize',22,'FontWeight','bold');
        uilabel(g,'Text',sprintf('Project directory exists: %d',isfolder(projectDir)));
        uilabel(g,'Text',sprintf('Report directory exists: %d',isfolder(reportDir)));
        uilabel(g,'Text',sprintf('Saved PNG plots detected: %d',numel(plotFiles)));
        uilabel(g,'Text',sprintf('Data Adapter exists: %d', ...
            isfile(fullfile(projectDir,'DynoForge_Data_Adapter.m'))));
        uilabel(g,'Text','Hardware verified: NO | Calibration verified: NO');
    end
end
