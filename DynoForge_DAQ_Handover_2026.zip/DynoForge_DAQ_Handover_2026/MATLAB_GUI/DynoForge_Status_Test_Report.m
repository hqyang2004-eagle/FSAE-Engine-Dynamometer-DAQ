function DynoForge_Status_Test_Report()
% Run while the DynoForge Step 10.5 UI remains open.
figs = findall(groot,'Type','figure');
for i = 1:numel(figs)
    if isappdata(figs(i),'DynoForgeStateReport')
        callback = getappdata(figs(i),'DynoForgeStateReport');
        callback();
        return;
    end
end
error('DynoForge:StatusWindowNotFound', ...
    'Step 10.5 window not found. Run DynoForge_Status_Manager first.');
end
