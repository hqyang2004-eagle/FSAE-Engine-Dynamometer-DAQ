function outputFile = DynoForge_Data_Logger()
% DynoForge Step 10.12 - OFFLINE synthetic data CSV export.
% No Simulink execution, model changes, or hardware access.
% Flow values are demonstration values; flow K-factor is NOT calibrated.

    outputDir = fullfile(pwd, 'Results', 'Step_10_12');
    if ~exist(outputDir, 'dir')
        mkdir(outputDir);
    end
    outputFile = fullfile(outputDir, 'DynoForge_Offline_Demo_Data.csv');

    % Deterministic 50 Hz example dataset (10 seconds, inclusive).
    t = (0:0.02:10)';
    rpm = 3000 .* (1 - exp(-t/2));
    forceN = 250 + 75 .* sin(2*pi*0.12*t);
    torqueNm = forceN .* 0.3048; % 12.000 in torque arm
    omegaRadS = rpm .* (2*pi/60);
    powerKW = torqueNm .* omegaRadS ./ 1000;
    tempInC = 20 + 0.10 .* t;
    tempOutC = 22 + 0.15 .* t;
    flowDemoLMin = 12 + 0.5 .* sin(2*pi*0.10*t);

    % Synthetic state/alarm values only. Not live controller decisions.
    alarmLevel = zeros(size(t));
    testState = 2 .* ones(size(t));
    calibrationConfirmed = zeros(size(t));
    flowCalibrated = zeros(size(t));
    source = repmat({'OFFLINE_SYNTHETIC'}, numel(t), 1);

    T = table(t, forceN, rpm, torqueNm, omegaRadS, powerKW, ...
        tempInC, tempOutC, flowDemoLMin, alarmLevel, testState, ...
        calibrationConfirmed, flowCalibrated, source, ...
        'VariableNames', {'Time_s','Force_N','RPM_rpm', ...
        'Torque_Nm','AngularVelocity_rad_s','Power_kW', ...
        'TempIn_degC','TempOut_degC','Flow_Demo_L_min', ...
        'AlarmLevel_Demo','TestState_Demo', ...
        'Calibration_Confirmed','Flow_Calibrated','Data_Source'});

    % Avoid overwriting a previous result without permission.
    if exist(outputFile, 'file')
        error('DynoForge:FileExists', [ ...
            'Output file already exists: %s\n' ...
            'Rename or move the previous CSV before rerunning.'], outputFile);
    end

    writetable(T, outputFile);
    fprintf('\n===== STEP 10.12 CSV EXPORT =====\n');
    fprintf('PASS | CSV created: %s\n', outputFile);
    fprintf('Rows: %d | Columns: %d\n', height(T), width(T));
    fprintf('Sample interval: 0.02 s | Nominal rate: 50 Hz\n');
    fprintf('Source: OFFLINE_SYNTHETIC (NOT measured)\n');
    fprintf('Calibration_Confirmed: 0 (NOT verified)\n');
    fprintf('Flow K-factor: NOT CALIBRATED\n');
    fprintf('No Simulink or hardware accessed.\n');
    fprintf('Run DynoForge_Data_Logger_Test_Report() next.\n');
    fprintf('=================================\n');
end
