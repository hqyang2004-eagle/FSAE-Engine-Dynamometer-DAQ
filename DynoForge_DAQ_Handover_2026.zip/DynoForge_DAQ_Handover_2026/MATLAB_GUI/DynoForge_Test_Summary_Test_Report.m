function DynoForge_Test_Summary_Test_Report()
% DynoForge Step 10.13 independent read-back verification.
    baseDir=fileparts(mfilename('fullpath'));
    inFile=fullfile(baseDir,'Results','Step_10_12','DynoForge_Offline_Demo_Data.csv');
    outDir=fullfile(baseDir,'Results','Step_10_13');
    sumFile=fullfile(outDir,'DynoForge_Offline_Test_Summary.csv');
    pngFile=fullfile(outDir,'DynoForge_Offline_Test_Curves.png');
    fprintf('\n===== STEP 10.13 OFFLINE VERIFICATION =====\n');
    filesOK=isfile(inFile)&&isfile(sumFile)&&isfile(pngFile);
    if ~filesOK
        fprintf('FAIL | REQUIRED_FILES\nSTEP 10.13 NOT COMPLETE\n');
        return;
    end
    T=readtable(inFile); S=readtable(sumFile);
    expected={'Sample_Count';'Duration_s';'Sampling_Rate_Hz'; ...
        'Peak_RPM_rpm';'Peak_RPM_Time_s';'Peak_Torque_Nm'; ...
        'Peak_Torque_Time_s';'Peak_Power_kW';'Peak_Power_Time_s'};
    schemaOK=isequal(S.Properties.VariableNames,{'Metric','Value'}) && ...
        isequal(cellstr(string(S.Metric)),expected);
    if ~schemaOK
        fprintf('PASS | REQUIRED_FILES\nFAIL | SUMMARY_SCHEMA\nSTEP 10.13 FAILED\n');
        return;
    end
    [r,ir]=max(T.RPM_rpm);[q,iq]=max(T.Torque_Nm);[p,ip]=max(T.Power_kW);
    expectedValues=[height(T);T.Time_s(end)-T.Time_s(1); ...
        1/median(diff(T.Time_s));r;T.Time_s(ir);q;T.Time_s(iq);p;T.Time_s(ip)];
    metricsOK=all(isfinite(S.Value)) && ...
        all(abs(S.Value-expectedValues)<1e-6);
    sourceOK=all(strcmp(string(T.Data_Source),'OFFLINE_SYNTHETIC'));
    calOK=all(T.Calibration_Confirmed==0)&&all(T.Flow_Calibrated==0);
    info=imfinfo(pngFile);
    imageOK=info.Width>=800 && info.Height>=600;
    checks=[filesOK schemaOK metricsOK sourceOK calOK imageOK];
    labels={'REQUIRED_FILES','SUMMARY_SCHEMA','PEAK_METRICS', ...
        'SYNTHETIC_SOURCE','CALIBRATION_UNCONFIRMED','PLOT_IMAGE'};
    for i=1:numel(checks)
        if checks(i),status='PASS';else,status='FAIL';end
        fprintf('%s | %s\n',status,labels{i});
    end
    if all(checks)
        fprintf('STEP 10.13 OFFLINE SUMMARY TEST PASSED\n');
    else
        fprintf('STEP 10.13 OFFLINE SUMMARY TEST FAILED\n');
    end
    fprintf('Simulink/hardware: NOT TESTED\n');
    fprintf('==========================================\n');
end
