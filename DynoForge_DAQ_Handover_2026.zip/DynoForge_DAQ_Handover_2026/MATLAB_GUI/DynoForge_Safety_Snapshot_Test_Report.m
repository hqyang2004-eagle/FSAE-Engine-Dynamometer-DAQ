function report = DynoForge_Safety_Snapshot_Test_Report()
% Step 10.14C-4: actual desktop snapshot + negative fault-state tests.
% No model writes, hardware build, or GUI manipulation.
fprintf('\n===== STEP 10.14C-4 SAFETY DISPLAY VERIFICATION =====\n');
model='ME486C_Dyno_DAQ_Quality_Development';
load_system(model);
assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
    'Model must be stopped.');
assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
    'Normal desktop mode required.');
cmd={'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
for k=1:numel(cmd)
    assert(strcmp(strtrim(get_param([model '/' cmd{k}],'Value')),'0'), ...
        'Operator commands must remain zero.');
end
fprintf('PASS | COMMAND_PRECHECK\n');
in=Simulink.SimulationInput(model);
in=in.setModelParameter('StopTime','0.20','ReturnWorkspaceOutputs','on');
out=sim(in);
D=DynoForge_Data_Adapter(out);
assert(D.LogCount==39);
fprintf('PASS | REAL_SIMULATION_39_LOGS\n');
actual=DynoForge_Safety_Snapshot_Check(D);
fprintf('INFO | Actual state=%s (%g), AlarmLevel=%g, AlarmCode=%g\n', ...
    actual.StateText,actual.State,actual.AlarmLevel,actual.AlarmCodeRaw);
if actual.Passed
    fprintf('PASS | ACTUAL_SNAPSHOT_CONSISTENCY\n');
else
    fprintf('REVIEW | ACTUAL_SNAPSHOT_CONSISTENCY: %s\n', ...
        strjoin(actual.FailedChecks,', '));
end
% Inject faults into COPIES of real logged snapshots, never into Simulink.
negative = {'FAULT_WITH_READY','FAULT_WITHOUT_LATCH', ...
    'SHUTDOWN_WITHOUT_LEVEL3','INVALID_STATE','INVALID_ALARM_LEVEL', ...
    'MISSING_SIGNAL','NONFINITE_SIGNAL','FALSE_HARDWARE_VERIFIED'};
passed=0;
for k=1:numel(negative)
    bad=D;
    switch negative{k}
        case 'FAULT_WITH_READY'
            bad.Signals.SEQ_State.Value(end)=4;
            bad.Signals.SEQ_Ready.Value(end)=1;
        case 'FAULT_WITHOUT_LATCH'
            bad.Signals.SEQ_State.Value(end)=4;
            bad.Signals.SEQ_Ready.Value(end)=0;
            bad.Signals.SEQ_Permit.Value(end)=0;
            bad.Signals.SEQ_Active.Value(end)=0;
            bad.Signals.SEQ_Fault_Latched.Value(end)=0;
        case 'SHUTDOWN_WITHOUT_LEVEL3'
            bad.Signals.ALM_Shutdown.Value(end)=1;
            bad.Signals.ALM_Level.Value(end)=0;
        case 'INVALID_STATE'
            bad.Signals.SEQ_State.Value(end)=9;
        case 'INVALID_ALARM_LEVEL'
            bad.Signals.ALM_Level.Value(end)=7;
        case 'MISSING_SIGNAL'
            bad.Signals=rmfield(bad.Signals,'ALM_Level');
        case 'NONFINITE_SIGNAL'
            bad.Signals.SEQ_State.Value(end)=NaN;
        case 'FALSE_HARDWARE_VERIFIED'
            bad.HardwareVerified=true;
    end
    rejected=false;
    try
        result=DynoForge_Safety_Snapshot_Check(bad);
        rejected=~result.Passed;
    catch
        rejected=true;
    end
    if rejected
        fprintf('PASS | REJECT_%s\n',negative{k});passed=passed+1;
    else
        fprintf('FAIL | REJECT_%s\n',negative{k});
    end
end
fprintf('\n===== STEP 10.14C-4 SUMMARY =====\n');
fprintf('Negative tests passed: %d / %d\n',passed,numel(negative));
report=struct('Actual',actual,'NegativeTestsPassed',passed, ...
    'NegativeTestsTotal',numel(negative), ...
    'Passed',actual.Passed && passed==numel(negative));
if report.Passed
    fprintf('STEP 10.14C-4 OFFLINE CONSISTENCY TEST PASSED\n');
else
    fprintf('STEP 10.14C-4 REQUIRES REVIEW\n');
end
fprintf('Alarm code mapping: NOT VERIFIED\n');
fprintf('Hardware safety and physical calibration: NOT VERIFIED\n');
fprintf('==========================================\n');
end
