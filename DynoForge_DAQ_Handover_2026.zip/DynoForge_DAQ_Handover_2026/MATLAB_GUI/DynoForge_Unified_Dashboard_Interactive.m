function app = DynoForge_Unified_Dashboard_Interactive(D)
% Step 10.14C-3. Offline multi-run dashboard, no hardware commands.
% RUN: Normal desktop simulation only; REFRESH: redraw cached data.
% CLEAR: clear display only. Close window to release controls.
validateDashboard(D);
fig = uifigure('Name','DynoForge | Step 10.14C-3 Multi-Run Dashboard', ...
    'Position',[80 70 1240 790]);
root = uigridlayout(fig,[4 1]);
root.RowHeight={48,46,290,'1x'}; root.Padding=[12 12 12 12];
uilabel(root,'Text','DynoForge | Desktop Simulation Dashboard', ...
    'FontSize',22,'FontWeight','bold');
controls=uigridlayout(root,[1 5]); controls.ColumnWidth={160,160,160,'1x',300};
runBtn=uibutton(controls,'push','Text','RUN SIMULATION');
refreshBtn=uibutton(controls,'push','Text','REFRESH DASHBOARD');
clearBtn=uibutton(controls,'push','Text','CLEAR DISPLAY');
uilabel(controls,'Text','Read-only display; no hardware deployment', ...
    'FontColor',[0.65 0.27 0.12]);
statusLabel=uilabel(controls,'Text','DESKTOP SIMULATION | CALIBRATION NOT VERIFIED', ...
    'HorizontalAlignment','right','FontSize',11);
mid=uigridlayout(root,[1 2]);mid.ColumnWidth={'1x','1x'};
p1=uipanel(mid,'Title','Engineering values (latest sample)');
p2=uipanel(mid,'Title','Status / quality (latest sample)');
mg=uigridlayout(p1,[9 2]);mg.ColumnWidth={'1x','1x'};
sg=uigridlayout(p2,[12 2]);sg.ColumnWidth={'1x','1x'};
metricSpec={'Force','ENG_Force_N','N';'RPM','ENG_RPM','rpm'; ...
    'Torque','ENG_Torque_Nm','N m';'Power','ENG_Power_kW','kW'; ...
    'Inlet temperature','ENG_Temp_In_C','deg C'; ...
    'Outlet temperature','ENG_Temp_Out_C','deg C'; ...
    'Flow','ENG_Flow_Lmin','L/min'; ...
    'Temperature difference','ENG_Delta_T_C','deg C'; ...
    'Cooling power','ENG_Cooling_Power_kW','kW'};
metricLabels=gobjects(9,1);
for k=1:9
    uilabel(mg,'Text',metricSpec{k,1});
    metricLabels(k)=uilabel(mg,'Text','--','HorizontalAlignment','right');
end
statusNames={'SEQ_State','SEQ_Active','SEQ_Ready','SEQ_Fault_Latched', ...
    'SEQ_Permit','SQ_All_Sensors_OK','SQ_Quality_Fault_Code', ...
    'SQ_Quality_Warning','CAL_All_Params_Valid', ...
    'CAL_Calibration_Complete','ALM_Level','ALM_Code'};
statusLabels=gobjects(12,1);
for k=1:12
    uilabel(sg,'Text',strrep(statusNames{k},'_',' '));
    statusLabels(k)=uilabel(sg,'Text','--','HorizontalAlignment','right');
end
plotGrid=uigridlayout(root,[1 3]);
plotSpec={'ENG_RPM','RPM','rpm';'ENG_Torque_Nm','Torque','N m'; ...
    'ENG_Power_kW','Power','kW'};
axesList=gobjects(3,1);
for k=1:3
    axesList(k)=uiaxes(plotGrid);
    title(axesList(k),plotSpec{k,2});
    xlabel(axesList(k),'Time (s)'); ylabel(axesList(k),plotSpec{k,3});
    grid(axesList(k),'on');
end
% Shared GUI state is stored in fig.UserData, not in stale closures.
fig.UserData=struct('Dashboard',D,'DisplayCleared',false, ...
    'RunCount',0,'RefreshCount',0,'LastError','');
runBtn.ButtonPushedFcn=@runSimulation;
refreshBtn.ButtonPushedFcn=@refreshDisplay;
clearBtn.ButtonPushedFcn=@clearDisplay;
render(D);
app=struct('Figure',fig,'RunButton',runBtn,'RefreshButton',refreshBtn, ...
    'ClearButton',clearBtn,'StatusLabel',statusLabel, ...
    'MetricLabels',metricLabels,'StatusLabels',statusLabels, ...
    'Axes',axesList,'MetricCount',9,'StatusCount',12,'PlotCount',3, ...
    'SetDashboard',@setDashboard,'GetState',@getState, ...
    'Refresh',@refreshDisplay,'Clear',@clearDisplay);

    function state=getState()
        if ~isvalid(fig),error('DynoForge:Closed','Dashboard window is closed.');end
        state=fig.UserData;
    end
    function setDashboard(next)
        % Inject an already-validated desktop simulation snapshot.
        validateDashboard(next);
        s=fig.UserData;s.Dashboard=next;s.DisplayCleared=false;
        fig.UserData=s;
        render(next);
    end
    function render(data)
        for j=1:9
            sig=data.Signals.(metricSpec{j,2});
            metricLabels(j).Text=sprintf('%.5g %s (t=%.3f s)', ...
                sig.Value(end),metricSpec{j,3},sig.Time_s(end));
        end
        for j=1:12
            sig=data.Signals.(statusNames{j});
            v=sig.Value(end);
            val=sprintf('%.5g',v);
            if strcmp(statusNames{j},'SEQ_State') && isfinite(v) && ...
                    v==floor(v) && v>=0 && v<=4
                states={'IDLE','READY','RUNNING','STOPPING','FAULT'};
                val=sprintf('%d (%s)',v,states{v+1});
            end
            statusLabels(j).Text=val;
        end
        for j=1:3
            sig=data.Signals.(plotSpec{j,1});
            cla(axesList(j));
            plot(axesList(j),sig.Time_s,sig.Value,'LineWidth',1.4);
            grid(axesList(j),'on');
        end
        s=fig.UserData;s.DisplayCleared=false;fig.UserData=s;
        statusLabel.Text=sprintf('DESKTOP SIMULATION | Run %d | Refresh %d | UNCALIBRATED', ...
            s.RunCount,s.RefreshCount);
        drawnow limitrate;
    end
    function refreshDisplay(~,~)
        if ~isvalid(fig),return;end
        s=fig.UserData;s.RefreshCount=s.RefreshCount+1;fig.UserData=s;
        render(s.Dashboard);
    end
    function clearDisplay(~,~)
        if ~isvalid(fig),return;end
        for j=1:9,metricLabels(j).Text='--';end
        for j=1:12,statusLabels(j).Text='--';end
        for j=1:3,cla(axesList(j));grid(axesList(j),'on');end
        s=fig.UserData;s.DisplayCleared=true;fig.UserData=s;
        statusLabel.Text='DISPLAY CLEARED | Model unchanged';
    end
    function runSimulation(~,~)
        runBtn.Enable='off';refreshBtn.Enable='off';clearBtn.Enable='off';
        c=onCleanup(@restoreButtons);
        statusLabel.Text='Running 0.20 s desktop simulation...';drawnow;
        try
            model='ME486C_Dyno_DAQ_Quality_Development';
            load_system(model);
            assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
                'Model simulation must be stopped.');
            assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
                'Normal simulation mode required.');
            cmds={'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
            for j=1:numel(cmds)
                path=[model '/' cmds{j}];
                assert(getSimulinkBlockHandle(path)~=-1 && ...
                    strcmp(strtrim(get_param(path,'Value')),'0'), ...
                    'Operator command not zero: %s',cmds{j});
            end
            input=Simulink.SimulationInput(model);
            input=input.setModelParameter('StopTime','0.20', ...
                'ReturnWorkspaceOutputs','on');
            out=sim(input);
            next=DynoForge_Data_Adapter(out);
            s=fig.UserData;s.RunCount=s.RunCount+1;s.LastError='';
            fig.UserData=s;
            setDashboard(next);
            fprintf('PASS | DESKTOP_RUN %d (39 validated logs)\n',s.RunCount);
        catch ME
            s=fig.UserData;s.LastError=ME.message;fig.UserData=s;
            statusLabel.Text='RUN FAILED | Last valid snapshot preserved';
            fprintf('FAIL | DESKTOP_RUN: %s\n',ME.message);
            uialert(fig,ME.message,'Offline simulation failed');
        end
        function restoreButtons()
            if isvalid(fig)
                runBtn.Enable='on';refreshBtn.Enable='on';clearBtn.Enable='on';
            end
        end
    end
end

function validateDashboard(D)
assert(isstruct(D) && isfield(D,'Signals') && ...
    isfield(D,'Source') && strcmp(D.Source,'SIMULINK_DESKTOP_SIMULATION') && ...
    isfield(D,'HardwareVerified') && ~D.HardwareVerified && ...
    isfield(D,'SensorCalibrationVerified') && ~D.SensorCalibrationVerified && ...
    isfield(D,'LogCount') && D.LogCount==39, ...
    'Expected validated uncalibrated 39-log desktop simulation data.');
required={'ENG_Force_N','ENG_RPM','ENG_Temp_In_C','ENG_Temp_Out_C', ...
    'ENG_Flow_Lmin','ENG_Torque_Nm','ENG_Power_kW','ENG_Delta_T_C', ...
    'ENG_Cooling_Power_kW','SEQ_State','SEQ_Active','SEQ_Ready', ...
    'SEQ_Fault_Latched','SEQ_Permit','SQ_All_Sensors_OK', ...
    'SQ_Quality_Fault_Code','SQ_Quality_Warning', ...
    'CAL_All_Params_Valid','CAL_Calibration_Complete','ALM_Level','ALM_Code'};
for k=1:numel(required)
    assert(isfield(D.Signals,required{k}), 'Missing %s',required{k});
    s=D.Signals.(required{k});
    assert(isfield(s,'Time_s') && isfield(s,'Value') && ...
        ~isempty(s.Value) && numel(s.Value)==numel(s.Time_s) && ...
        all(isfinite(s.Value)) && all(isfinite(s.Time_s)) && ...
        all(diff(s.Time_s)>0),'Invalid %s',required{k});
end
end
