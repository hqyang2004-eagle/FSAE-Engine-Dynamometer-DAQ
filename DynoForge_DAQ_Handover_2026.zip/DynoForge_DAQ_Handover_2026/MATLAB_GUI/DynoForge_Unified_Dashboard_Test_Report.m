function report = DynoForge_Unified_Dashboard_Test_Report()
% Step 10.14C-2: Run 0.20 s Normal desktop simulation and show snapshot.
% No model modifications, control writes, or hardware deployment.
model='ME486C_Dyno_DAQ_Quality_Development';
load_system(model);
fprintf('\n===== STEP 10.14C-2 VERIFICATION =====\n');
assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
    'Simulation must be stopped.');
assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
    'Simulation Mode must be Normal.');
cmds={'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
for k=1:numel(cmds)
    p=[model '/' cmds{k}];
    assert(getSimulinkBlockHandle(p)~=-1 && ...
        strcmp(strtrim(get_param(p,'Value')),'0'), ...
        'Command must be zero: %s',cmds{k});
end
fprintf('PASS | COMMAND_PRECHECK\n');
in=Simulink.SimulationInput(model);
in=in.setModelParameter('StopTime','0.20','ReturnWorkspaceOutputs','on');
out=sim(in);
fprintf('PASS | DESKTOP_SIMULATION\n');
D=DynoForge_Data_Adapter(out);
assert(D.LogCount==39 && numel(fieldnames(D.Signals))==39);
fprintf('PASS | 39_LOG_DATA_ADAPTED\n');
assert(~D.HardwareVerified && ~D.SensorCalibrationVerified && ...
    strcmp(D.Source,'SIMULINK_DESKTOP_SIMULATION'));
fprintf('PASS | SIMULATION_AND_CALIBRATION_LABELS\n');
app=DynoForge_Unified_Dashboard(D);
assert(isvalid(app.Figure) && app.MetricCount==9 && ...
    app.StatusCount==12 && app.PlotCount==3);
fprintf('PASS | DASHBOARD_LAYOUT\n');
plotNames={'ENG_RPM','ENG_Torque_Nm','ENG_Power_kW'};
for k=1:numel(plotNames)
    s=D.Signals.(plotNames{k});
    assert(numel(s.Time_s)==numel(s.Value) && ...
        all(diff(s.Time_s)>0) && all(isfinite(s.Value)));
end
fprintf('PASS | THREE_PLOT_DATASETS\n');
report=struct('Passed',true,'Dashboard',D,'App',app);
fprintf('\nSTEP 10.14C-2 DASHBOARD DISPLAY TEST PASSED\n');
fprintf('Hardware/calibration: NOT VERIFIED\n');
fprintf('Live streaming/refresh: NOT TESTED\n');
fprintf('==========================================\n');
end
