function DynoForge_Command_Test_Report()
% Prints the verification result from the Step 10.4 offline UI.
    figs = findall(groot,'Type','figure');
    found = false;
    for i = 1:numel(figs)
        if isappdata(figs(i),'DynoForgeReport')
            callback = getappdata(figs(i),'DynoForgeReport');
            callback();
            found = true;
            break;
        end
    end
    if ~found
        error('DynoForge:NoWindow', ...
            'Step 10.4 window not found. Run DynoForge_Command_Interface first.');
    end
end
