function DynoForge_Alarm_Test_Report()
% DynoForge Step 10.10: Print report for the open offline alarm UI.
figs=findall(groot,'Type','figure');
for k=1:numel(figs)
    if isappdata(figs(k),'DynoForgeAlarmReport')
        reporter=getappdata(figs(k),'DynoForgeAlarmReport');
        reporter();
        return;
    end
end
fprintf('STEP 10.10 NOT TESTED: Open DynoForge_Alarm_Display first.\n');
end
