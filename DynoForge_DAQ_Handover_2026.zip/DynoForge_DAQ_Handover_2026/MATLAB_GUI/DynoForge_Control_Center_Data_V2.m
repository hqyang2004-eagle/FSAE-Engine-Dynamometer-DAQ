function app = DynoForge_Control_Center_Data_V2(projectDir)
if nargin<1 || isempty(projectDir)
    projectDir = 'C:\DynoForge_Test';
end
file = fullfile(projectDir,'Results','ControlCenter_Data','DynoForge_ControlCenter_Latest.mat');
assert(isfile(file),'Snapshot file not found.');
x = load(file,'Snapshot');
S = x.Snapshot;
assert(S.DesktopSimulationOnly && ~S.HardwareVerified,'Invalid source verification.');
D = S.Data;
names = fieldnames(D.Signals);
assert(numel(names)==39,'Expected 39 signals.');
fig = uifigure('Name','DynoForge | Data Viewer V2 | DESKTOP SIMULATION ONLY', ...
    'Position',[100 80 1250 760],'Color',[0.96 0.97 0.98]);
g = uigridlayout(fig,[3 2]);
g.RowHeight = {55,200,'1x'};
g.ColumnWidth = {350,'1x'};
titleLabel = uilabel(g,'Text','DynoForge | Unified Data Viewer', ...
    'FontSize',23,'FontWeight','bold');
titleLabel.Layout.Row=1;
titleLabel.Layout.Column=[1 2];
info = uitextarea(g,'Editable','off');
info.Layout.Row=2;
info.Layout.Column=1;
info.Value = {
    'SOURCE: DESKTOP SIMULATION ONLY'
    sprintf('Logged signals: %d',D.LogCount)
    sprintf('Alarm Code: %g',D.AlarmCode)
    sprintf('Alarm Level: %g',D.AlarmLevel)
    sprintf('Calibration Complete: %g',D.CalibrationComplete)
    'Hardware verified: NO'
    'Sensor calibration verified: NO'};
tbl = uitable(g);
tbl.Layout.Row=3;
tbl.Layout.Column=1;
rows = cell(numel(names),3);
for k=1:numel(names)
    v=D.Signals.(names{k}).Value;
    rows{k,1}=names{k};
    rows{k,2}=double(v(end));
    rows{k,3}=numel(v);
end
tbl.Data=rows;
tbl.ColumnName={'Signal','Last Value','Samples'};
right = uigridlayout(g,[2 1]);
right.Layout.Row=[2 3];
right.Layout.Column=2;
right.RowHeight={45,'1x'};
drop = uidropdown(right,'Items',names,'Value',names{1});
ax = uiaxes(right);
ax.XLabel.String='Time (s)';
ax.YLabel.String='Logged value';
plotSignal(drop.Value);
drop.ValueChangedFcn=@(~,~)plotSignal(drop.Value);
app = struct('Figure',fig,'Dropdown',drop,'Axes',ax, ...
    'Table',tbl,'Snapshot',S,'SignalNames',{names});
    function plotSignal(name)
        sig=D.Signals.(name);
        t=double(sig.Time_s(:));
        v=double(sig.Value(:));
        plot(ax,t,v,'LineWidth',1.8);
        grid(ax,'on');
        title(ax,strrep(name,'_','\_'));
        xlabel(ax,'Time (s)');
        ylabel(ax,'Logged value');
    end
end
