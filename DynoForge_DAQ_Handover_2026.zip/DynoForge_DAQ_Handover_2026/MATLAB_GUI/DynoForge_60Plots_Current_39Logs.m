%% DynoForge 60-Plot Automatic Report - Current 39-Log Model
% Run from MATLAB Command Window after desktop simulation generated out.
% Generates original 4x15 plot layout and dashboard; absent signals N/A.
% No hardware access and no Simulink model modification.
clc;
root = 'C:\DynoForge_Test\Results';
if ~isfolder(root), mkdir(root); end
if evalin('base','exist(''out'',''var'')')~=1
    error('Missing base workspace variable out (SimulationOutput).');
end
simOut = evalin('base','out');
assert(isa(simOut,'Simulink.SimulationOutput'), 'out must be SimulationOutput.');
Dsrc = DynoForge_Data_Adapter(simOut);
assert(Dsrc.LogCount==39,'Expected 39 logged signals.');
fields = fieldnames(Dsrc.Signals);
t = Dsrc.Signals.(fields{1}).Time_s(:);
D = table(t,'VariableNames',{'Time_s'});
for j=1:numel(fields)
    nm = fields{j};
    ss = Dsrc.Signals.(nm);
    assert(isequal(ss.Time_s(:),t),'Signal time alignment mismatch: %s',nm);
    D.(nm) = ss.Value(:);
end
% Aliases to original report's engineering/cooling field labels.
% Each alias refers directly to a logged ENG_ signal, not synthetic data.
aliases = { ...
 'Torque_Nm','ENG_Torque_Nm'; 'Power_kW','ENG_Power_kW'; ...
 'RPM','ENG_RPM'; 'Force_N','ENG_Force_N'; ...
 'Temp_In_C','ENG_Temp_In_C'; 'Temp_Out_C','ENG_Temp_Out_C'; ...
 'Delta_T_C','ENG_Delta_T_C'; 'Cooling_Power_kW','ENG_Cooling_Power_kW'; ...
 'Flow_Lmin','ENG_Flow_Lmin'};
for j=1:size(aliases,1)
    D.(aliases{j,1}) = D.(aliases{j,2});
end
% Safety/fault channels from legacy CSV are intentionally NOT inferred
% from new ALM_/SEQ_ signals because semantics may differ.
stamp = datestr(now,'yyyymmdd_HHMMSS_FFF');
reportDir = fullfile(root,['DynoForge_60Plots_' stamp]);
folders = {'01_Raw_Data','02_Engineering_Plots','03_Cooling_Plots', ...
 '04_Safety_and_Faults','05_Data_Quality','06_Dashboard','07_Test_Report'};
mkdir(reportDir); for j=1:numel(folders), mkdir(fullfile(reportDir,folders{j})); end
source = 'SIMULINK_DESKTOP_SIMULATION / 39 real logged timeseries';
sourceName = 'Current_39_Log_SimulationOutput';
writetable(D,fullfile(reportDir,'01_Raw_Data','All_Logged_Signals.csv'));
save(fullfile(reportDir,'01_Raw_Data','Simulation_Data.mat'),'D','Dsrc','source');
fprintf('PASS | 39_LOGS_LOADED\n');
fprintf('PASS | ENGINEERING_ALIASES_MAPPED\n');
G = { ...
'Engineering', '02_Engineering_Plots', { ...
 {'Torque_Nm','Torque (N m)','signal'}, {'Power_kW','Power (kW)','signal'}, ...
 {'RPM','RPM','signal'}, {'Force_N','Force (N)','signal'}, ...
 {'Torque_Nm','Torque histogram','hist'}, {'Power_kW','Power histogram','hist'}, ...
 {'Torque_Nm','Torque moving average','smooth'}, {'Power_kW','Power moving average','smooth'}, ...
 {'Torque_Nm','Torque rate of change','rate'}, {'Power_kW','Power rate of change','rate'}, ...
 {'Torque_Nm','Torque cumulative integral','integral'}, {'Power_kW','Power cumulative integral','integral'}, ...
 {'Torque_Nm','Torque boxplot style','box'}, {'Power_kW','Power boxplot style','box'}, ...
 {'RPM','RPM versus torque','scatterTorque'} } ; ...
'Cooling', '03_Cooling_Plots', { ...
 {'Temp_In_C','Inlet temperature','signal'}, {'Temp_Out_C','Outlet temperature','signal'}, ...
 {'Delta_T_C','Cooling temperature difference','signal'}, {'Cooling_Power_kW','Cooling power','signal'}, ...
 {'Flow_Lmin','Coolant flow rate','signal'}, {'Delta_T_C','Delta T histogram','hist'}, ...
 {'Cooling_Power_kW','Cooling power histogram','hist'}, {'Delta_T_C','Delta T moving average','smooth'}, ...
 {'Cooling_Power_kW','Cooling power moving average','smooth'}, {'Delta_T_C','Delta T rate of change','rate'}, ...
 {'Cooling_Power_kW','Cooling power rate of change','rate'}, {'Cooling_Power_kW','Cooling energy integral','integral'}, ...
 {'Delta_T_C','Delta T boxplot style','box'}, {'Flow_Valid','Flow valid status','step'}, ...
 {'Cooling_Valid','Cooling valid status','step'} } ; ...
'Safety', '04_Safety_and_Faults', { ...
 {'OverTemp_Trip','Overtemperature trip','step'}, {'Temp_Sensor_Trip','Temperature sensor trip','step'}, ...
 {'Cooling_Data_Trip','Cooling data trip','step'}, {'Low_Flow_Trip','Low flow trip','step'}, ...
 {'Overspeed_Trip','Overspeed trip','step'}, {'RPM_Loss_Trip','RPM loss trip','step'}, ...
 {'Start_Timeout_Fault','Startup timeout fault','step'}, {'EStop_Trip','Emergency stop trip','step'}, ...
 {'Safety_Chain_Trip','Safety chain trip','step'}, {'Any_Trip','Any active trip','step'}, ...
 {'Trip_Latched','Latched trip','step'}, {'Shutdown_Request','Shutdown request','step'}, ...
 {'Run_Permit','Run permit','step'}, {'Controller_State','Controller state','step'}, ...
 {'Fault_Code','Fault code','step'} } ; ...
'DataQuality', '05_Data_Quality', { ...
 {'Time_s','Sampling interval','dt'}, {'Time_s','Sampling interval histogram','dthist'}, ...
 {'Time_s','Sample index versus time','index'}, {'Time_s','Cumulative elapsed time','elapsed'}, ...
 {'Time_s','Sample interval deviation','jitter'}, {'Time_s','Missing values by channel','missing'}, ...
 {'Time_s','Nonfinite values by channel','nonfinite'}, {'Time_s','Channel sample count','count'}, ...
 {'Time_s','Channel minimum values','min'}, {'Time_s','Channel maximum values','max'}, ...
 {'Time_s','Channel mean values','mean'}, {'Time_s','Channel standard deviations','std'}, ...
 {'Time_s','Channel dynamic range','range'}, {'Time_s','Channel first to last change','change'}, ...
 {'Time_s','Channel constant-value check','constant'} } ...
};
manifest = cell(0,5); plotCount=0; missingCount=0;
for g=1:size(G,1)
    section=G{g,1}; folder=fullfile(reportDir,G{g,2}); specs=G{g,3};
    for k=1:numel(specs)
        spec=specs{k}; field=spec{1}; ttl=spec{2}; mode=spec{3};
        fig=figure('Visible','off','Color','w','Position',[100 100 1120 650]);
        ax=axes(fig); hold(ax,'on'); grid(ax,'on'); box(ax,'on');
        status='OK'; reason='';
        try
            [ok,reason] = drawPlot(ax,D,t,field,mode);
            if ~ok
                status='N/A'; missingCount=missingCount+1;
                cla(ax); axis(ax,'off');
                text(ax,.5,.5,['N/A - ' reason],'Units','normalized', ...
                    'HorizontalAlignment','center','FontSize',15,'Interpreter','none');
            end
        catch ME
            status='ERROR'; reason=ME.message; cla(ax); axis(ax,'off');
            text(ax,.5,.5,['Plot error: ' reason],'Units','normalized', ...
                'HorizontalAlignment','center','Interpreter','none');
        end
        title(ax,sprintf('DynoForge | %s | %02d | %s',section,k,ttl),'Interpreter','none');
        subtitle(ax,['Data source: ' sourceName],'Interpreter','none');
        filename=sprintf('%02d_%s.png',k,regexprep(ttl,'[^a-zA-Z0-9]','_'));
        exportgraphics(fig,fullfile(folder,filename),'Resolution',170);
        close(fig); plotCount=plotCount+1;
        manifest(end+1,:)={section,k,ttl,status,reason}; %#ok<AGROW>
    end
end
M=cell2table(manifest,'VariableNames',{'Section','Number','Plot','Status','Reason'});
writetable(M,fullfile(reportDir,'07_Test_Report','Plot_Manifest.csv'));
% Per-channel descriptive statistics
v=D.Properties.VariableNames; stats=cell(numel(v),9);
for j=1:numel(v)
    x=D{:,j}; x=x(:); xf=x(isfinite(x));
    stats(j,1:3)={v{j},numel(x),sum(~isfinite(x))};
    if isempty(xf), stats(j,4:9)={NaN,NaN,NaN,NaN,NaN,NaN};
    else, stats(j,4:9)={min(xf),max(xf),mean(xf),std(xf),max(xf)-min(xf),xf(end)}; end
end
S=cell2table(stats,'VariableNames',{'Signal','Samples','Nonfinite','Minimum','Maximum','Mean','StdDev','Range','Last'});
writetable(S,fullfile(reportDir,'07_Test_Report','Signal_Statistics.csv'));
% Event log: changes in fault and controller signals; includes initial state.
events=cell(0,4);
fields={'OverTemp_Trip','Temp_Sensor_Trip','Cooling_Data_Trip','Low_Flow_Trip', ...
'Overspeed_Trip','RPM_Loss_Trip','Start_Timeout_Fault','EStop_Trip', ...
'Safety_Chain_Trip','Any_Trip','Trip_Latched','Shutdown_Request', ...
'Run_Permit','Controller_State','Fault_Code','Reset_Accepted'};
for j=1:numel(fields)
    if ~ismember(fields{j},v), continue; end
    x=D.(fields{j}); ixChange=[1; find(diff(x)~=0)+1];
    for q=1:numel(ixChange)
        ii=ixChange(q);
        events(end+1,:)={t(ii),fields{j},x(ii),ii}; %#ok<AGROW>
    end
end
E=cell2table(events,'VariableNames',{'Time_s','Signal','Value','SampleIndex'});
if ~isempty(E), E=sortrows(E,'Time_s'); end
writetable(E,fullfile(reportDir,'04_Safety_and_Faults','Fault_Events.csv'));
% Dashboard: only real channels; absent channels shown as N/A.
fig=figure('Visible','off','Color','w','Position',[80 80 1600 1100]);
layout=tiledlayout(fig,4,2,'Padding','compact','TileSpacing','compact');
dash={{'Torque_Nm','Torque (N m)'},{'Power_kW','Power (kW)'}, ...
 {'Delta_T_C','Delta T (C)'},{'Cooling_Power_kW','Cooling Power (kW)'}, ...
 {'Controller_State','Controller State'},{'Fault_Code','Fault Code'}, ...
 {'Shutdown_Request','Shutdown Request'},{'Run_Permit','Run Permit'}};
for j=1:numel(dash)
    ax=nexttile(layout); xname=dash{j}{1};
    if ismember(xname,v)
        plot(ax,t,D.(xname),'LineWidth',1.4); grid(ax,'on'); xlabel(ax,'Time (s)');
    else
        axis(ax,'off'); text(ax,.5,.5,'N/A','Units','normalized','HorizontalAlignment','center');
    end
    title(ax,dash{j}{2},'Interpreter','none');
end
title(layout,'DynoForge - Automatic Test Dashboard');
exportgraphics(fig,fullfile(reportDir,'06_Dashboard','DynoForge_Dashboard.png'),'Resolution',190);
savefig(fig,fullfile(reportDir,'06_Dashboard','DynoForge_Dashboard.fig')); close(fig);
% Human-readable summary
fid=fopen(fullfile(reportDir,'07_Test_Report','Test_Summary.txt'),'w');
if fid<0, error('Cannot create summary file.'); end
fprintf(fid,'DynoForge Automatic Test Report\n================================\n');
fprintf(fid,'Created: %s\nSource: %s\n',datestr(now),source);
fprintf(fid,'Source type: Simulink desktop simulation / hardware NOT verified\n');
fprintf(fid,'Rows: %d\nColumns: %d\nTime span: %.6f to %.6f s\n',height(D),width(D),t(1),t(end));
fprintf(fid,'Generated plots: %d (15 per category x 4)\nN/A plots: %d\n',plotCount,missingCount);
fprintf(fid,'WARNING: Graph count is not the count of independent measurements.\n');
fprintf(fid,'WARNING: A plot can be N/A if its source channel is not in the 39 logged signals.\n');
fprintf(fid,'WARNING: Offline simulation is not proof of real sensor acquisition or safety.\n');
fprintf(fid,'WARNING: Thresholds, flow calibration and RPM acquisition require validation.\n');
for j=1:numel(fields)
    if ismember(fields{j},v)
        x=D.(fields{j});
        fprintf(fid,'Last %-24s = %g\n',fields{j},x(end));
    end
end
fclose(fid);
fprintf('\n===== DynoForge Full Report =====\n');
fprintf('Source: %s\n',source);
fprintf('Folder: %s\n',reportDir);
fprintf('PNG plots: %d (N/A: %d) + dashboard\n',plotCount,missingCount);
fprintf('PASS: Report files generated. Review Plot_Manifest.csv for N/A/errors.\n');

function [ok,reason]=drawPlot(ax,D,t,field,mode)
 ok=true; reason=''; v=D.Properties.VariableNames;
 quality=ismember(mode,{'dt','dthist','index','elapsed','jitter','missing','nonfinite','count','min','max','mean','std','range','change','constant'});
 if quality
     n=height(D); d=diff(t); dtpos=d(isfinite(d));
     switch mode
         case 'dt', if isempty(d),ok=false;reason='Need 2+ samples';return;end; plot(ax,t(2:end),d); ylabel(ax,'dt (s)');
         case 'dthist', if isempty(d),ok=false;reason='Need 2+ samples';return;end; histogram(ax,d);xlabel(ax,'dt (s)');ylabel(ax,'Count');
         case 'index', plot(ax,1:n,t);xlabel(ax,'Sample index');ylabel(ax,'Time (s)');
         case 'elapsed', plot(ax,t,t-t(1));ylabel(ax,'Elapsed time (s)');
         case 'jitter', if isempty(dtpos),ok=false;reason='Need intervals';return;end;plot(ax,t(2:end),d-median(dtpos));ylabel(ax,'dt - median(dt) (s)');
         otherwise
             vals=zeros(1,width(D));
             for jj=1:width(D)
                 x=D{:,jj}; xf=x(isfinite(x));
                 switch mode
                     case {'missing','nonfinite'}, vals(jj)=sum(~isfinite(x));
                     case 'count', vals(jj)=sum(isfinite(x));
                     case 'min', vals(jj)=safeStat(xf,'min');
                     case 'max', vals(jj)=safeStat(xf,'max');
                     case 'mean', vals(jj)=safeStat(xf,'mean');
                     case 'std', vals(jj)=safeStat(xf,'std');
                     case 'range', vals(jj)=safeStat(xf,'range');
                     case 'change', if isempty(xf),vals(jj)=NaN;else,vals(jj)=xf(end)-xf(1);end
                     case 'constant', vals(jj)=double(numel(unique(xf))<=1 && ~isempty(xf));
                 end
             end
             bar(ax,vals); xticks(ax,1:width(D));xticklabels(ax,D.Properties.VariableNames);
             ax.XTickLabelRotation=70; xlabel(ax,'Signal'); ylabel(ax,mode);
     end
     return
 end
 if ~ismember(field,v),ok=false;reason=['Channel not logged: ' field];return;end
 x=D.(field); x=x(:); valid=isfinite(x)&isfinite(t);
 if ~any(valid),ok=false;reason=['No finite data: ' field];return;end
 switch mode
     case 'signal', plot(ax,t,x,'LineWidth',1.5);xlabel(ax,'Time (s)');ylabel(ax,field,'Interpreter','none');
     case 'step', stairs(ax,t,x,'LineWidth',1.5);xlabel(ax,'Time (s)');ylabel(ax,field,'Interpreter','none');
     case 'hist', histogram(ax,x(valid));xlabel(ax,field,'Interpreter','none');ylabel(ax,'Samples');
     case 'smooth', plot(ax,t,movmean(x,5,'omitnan'),'LineWidth',1.5);xlabel(ax,'Time (s)');ylabel(ax,[field ' (5-point MA)'],'Interpreter','none');
     case 'rate'
         good=diff(t)>0;
         if ~any(good),ok=false;reason='No positive time intervals';return;end
         tt=t(2:end); dx=diff(x); dt=diff(t); z=nan(size(dx));z(good)=dx(good)./dt(good);
         plot(ax,tt,z);xlabel(ax,'Time (s)');ylabel(ax,['d/dt ' field],'Interpreter','none');
     case 'integral', plot(ax,t,cumtrapz(t,x),'LineWidth',1.5);xlabel(ax,'Time (s)');ylabel(ax,['Integral of ' field],'Interpreter','none');
     case 'box'
         q=prctile(x(valid),[0 25 50 75 100]);
         plot(ax,1:5,q,'o-','LineWidth',1.5);xticks(ax,1:5);xticklabels(ax,{'Min','Q1','Median','Q3','Max'});ylabel(ax,field,'Interpreter','none');
     case 'scatterTorque'
         if ~ismember('Torque_Nm',v),ok=false;reason='Torque_Nm not logged';return;end
         y=D.Torque_Nm; good=isfinite(x)&isfinite(y);
         if ~any(good),ok=false;reason='No paired values';return;end
         scatter(ax,x(good),y(good),20,'filled');xlabel(ax,field,'Interpreter','none');ylabel(ax,'Torque (N m)');
     otherwise,ok=false;reason=['Unknown mode ' mode];
 end
end
function v=safeStat(x,mode)
 if isempty(x),v=NaN;return;end
 switch mode
 case 'min',v=min(x);case 'max',v=max(x);case 'mean',v=mean(x);
 case 'std',v=std(x);case 'range',v=max(x)-min(x);
 end
end
