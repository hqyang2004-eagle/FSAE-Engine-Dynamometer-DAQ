function report = DynoForge_Data_Adapter_Test_Report()
% Step 10.14C-1: Run a short desktop simulation and test the adapter.
% Requires a model that is safe to simulate offline in Normal mode.
% Does not alter saved model, command values, or deploy hardware.
model = 'ME486C_Dyno_DAQ_Quality_Development';
load_system(model);
fprintf('\n===== STEP 10.14C-1 VERIFICATION =====\n');
assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
    'Simulation must be stopped.');
assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
    'Model must be in Normal mode.');
commands = {'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
for k=1:numel(commands)
    path=[model '/' commands{k}];
    assert(getSimulinkBlockHandle(path)~=-1 && ...
        strcmp(strtrim(get_param(path,'Value')),'0'), ...
        'Unsafe operator command: %s',commands{k});
end
fprintf('PASS | COMMAND_PRECHECK\n');

% Explicitly request SimulationOutput without changing the saved model.
in = Simulink.SimulationInput(model);
in = in.setModelParameter('StopTime','0.20','ReturnWorkspaceOutputs','on');
try
    simOut = sim(in);
catch ME
    fprintf('FAIL | DESKTOP_SIMULATION: %s\n',ME.message);
    rethrow(ME);
end
fprintf('PASS | DESKTOP_SIMULATION\n');

dashboard = DynoForge_Data_Adapter(simOut);
fprintf('PASS | 39_TIMESERIES_VALIDATED\n');

counts = [numel(dashboard.Groups.Engineering), ...
          numel(dashboard.Groups.Quality), ...
          numel(dashboard.Groups.Calibration), ...
          numel(dashboard.Groups.Alarm), ...
          numel(dashboard.Groups.Sequence)];
assert(isequal(counts,[9 8 8 6 8]),'Unexpected signal group counts.');
fprintf('PASS | GROUP_COUNTS_9_8_8_6_8\n');

assert(strcmp(dashboard.Source,'SIMULINK_DESKTOP_SIMULATION') && ...
       ~dashboard.HardwareVerified && ~dashboard.SensorCalibrationVerified, ...
       'Source/calibration labels are incorrect.');
fprintf('PASS | SOURCE_AND_CALIBRATION_LABELS\n');

assert(~dashboard.TimeAlignmentAssumed,'Time alignment was assumed.');
fprintf('PASS | INDEPENDENT_TIMESTAMPS\n');

% Negative test: an empty SimulationOutput is missing all required logs.
% This tests the adapter rejection without using unsupported .set syntax.
negative = Simulink.SimulationOutput();
rejected=false;
try
    DynoForge_Data_Adapter(negative);
catch ME
    rejected=strcmp(ME.identifier,'DynoForge:MissingLogs');
end
assert(rejected,'Adapter failed to reject incomplete log sets.');
fprintf('PASS | MISSING_LOG_REJECTION\n');

report = struct('Passed',true,'LogCount',dashboard.LogCount, ...
    'GroupCounts',counts,'Dashboard',dashboard);
fprintf('\nSTEP 10.14C-1 DATA ADAPTER TEST PASSED\n');
fprintf('Actual sensor accuracy: NOT VERIFIED\n');
fprintf('Hardware deployment: NOT REQUESTED\n');
fprintf('==========================================\n');
end
