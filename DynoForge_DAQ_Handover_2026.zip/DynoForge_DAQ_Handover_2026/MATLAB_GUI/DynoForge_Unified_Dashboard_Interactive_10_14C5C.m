function app = DynoForge_Unified_Dashboard_Interactive_10_14C5C(D)
% DynoForge Step 10.14C-5C: desktop-only alarm-aware dashboard.
% Preserves 10.14C-3 controls and public app handles. No hardware writes.
validateDashboard(D);
fig=uifigure('Name','DynoForge | Step 10.14C-5C Alarm-Aware Dashboard', ...
    'Position',[60 45 1450 870]);
root=uigridlayout(fig,[4 1]);
root.RowHeight={50,52,365,'1x'};root.Padding=[12 12 12 12];root.RowSpacing=8;
uilabel(root,'Text','DynoForge | Desktop Simulation Dashboard', ...
    'FontSize',23,'FontWeight','bold');
controls=uigridlayout(root,[1 5]);
controls.ColumnWidth={155,165,140,'1x',290};
runBtn=uibutton(controls,'push','Text','RUN SIMULATION');
refreshBtn=uibutton(controls,'push','Text','REFRESH DASHBOARD');
clearBtn=uibutton(controls,'push','Text','CLEAR DISPLAY');
uilabel(controls,'Text','OFFLINE ONLY | No hardware deployment', ...
    'FontColor',[0.65 0.27 0.12],'FontSize',11);
statusLabel=uilabel(controls,'Text','DESKTOP SIMULATION | UNCALIBRATED', ...
    'HorizontalAlignment','right','FontSize',11);
mid=uigridlayout(root,[1 3]);mid.ColumnWidth={'1x','1.1x','1.2x'};
p1=uipanel(mid,'Title','Engineering values | Latest sample');
p2=uipanel(mid,'Title','Sequence / Quality / Calibration');
p3=uipanel(mid,'Title','Alarm & Safety | Verified bitmask');
mg=uigridlayout(p1,[9 2]);mg.ColumnWidth={'1x','1.2x'};mg.RowHeight=repmat({'1x'},1,9);
sg=uigridlayout(p2,[12 2]);sg.ColumnWidth={'1.35x','1x'};sg.RowHeight=repmat({'1x'},1,12);
ag=uigridlayout(p3,[9 1]);ag.RowHeight={34,30,30,30,30,30,30,30,'1x'};
metricSpec={'Force','ENG_Force_N','N';'RPM','ENG_RPM','rpm'; ...
    'Torque','ENG_Torque_Nm','N m';'Power','ENG_Power_kW','kW'; ...
    'Inlet temperature','ENG_Temp_In_C','deg C'; ...
    'Outlet temperature','ENG_Temp_Out_C','deg C'; ...
    'Flow','ENG_Flow_Lmin','L/min'; ...
    'Temperature difference','ENG_Delta_T_C','deg C'; ...
    'Cooling power','ENG_Cooling_Power_kW','kW'};
metricLabels=gobjects(9,1);
for k=1:9
    uilabel(mg,'Text',metricSpec{k,1},'FontSize',11);
    metricLabels(k)=uilabel(mg,'Text','--','HorizontalAlignment','right','FontSize',11);
end
statusNames={'SEQ_State','SEQ_Active','SEQ_Ready','SEQ_Fault_Latched', ...
    'SEQ_Permit','SQ_All_Sensors_OK','SQ_Quality_Fault_Code', ...
    'SQ_Quality_Warning','CAL_All_Params_Valid', ...
    'CAL_Calibration_Complete','ALM_Level','ALM_Code'};
statusDisplay={'Test state','Test active','Test ready','Fault latched', ...
    'Sequence permit','All sensors OK','Quality fault code', ...
    'Quality warning','Parameters valid','Calibration complete', ...
    'Alarm level','Alarm code'};
statusLabels=gobjects(12,1);
for k=1:12
    uilabel(sg,'Text',statusDisplay{k},'FontSize',11);
    statusLabels(k)=uilabel(sg,'Text','--','HorizontalAlignment','right','FontSize',11);
end
alarmLabels=gobjects(9,1);
for k=1:9
    alarmLabels(k)=uilabel(ag,'Text','--','FontSize',12);
end
alarmLabels(1).FontSize=16;alarmLabels(1).FontWeight='bold';
plotGrid=uigridlayout(root,[1 3]);plotGrid.ColumnWidth={'1x','1x','1x'};
plotSpec={'ENG_RPM','RPM','rpm';'ENG_Torque_Nm','Torque','N m'; ...
    'ENG_Power_kW','Power','kW'};
axesList=gobjects(3,1);
for k=1:3
    axesList(k)=uiaxes(plotGrid);
    title(axesList(k),plotSpec{k,2});
    xlabel(axesList(k),'Time (s)');ylabel(axesList(k),plotSpec{k,3});
    grid(axesList(k),'on');
end
fig.UserData=struct('Dashboard',D,'DisplayCleared',false, ...
    'RunCount',0,'RefreshCount',0,'LastError','');
runBtn.ButtonPushedFcn=@runSimulation;
refreshBtn.ButtonPushedFcn=@refreshDisplay;
clearBtn.ButtonPushedFcn=@clearDisplay;
render(D);
app=struct('Figure',fig,'RunButton',runBtn,'RefreshButton',refreshBtn, ...
    'ClearButton',clearBtn,'StatusLabel',statusLabel, ...
    'MetricLabels',metricLabels,'StatusLabels',statusLabels, ...
    'AlarmLabels',alarmLabels,'Axes',axesList,'MetricCount',9, ...
    'StatusCount',12,'PlotCount',3,'AlarmCount',9, ...
    'SetDashboard',@setDashboard,'GetState',@getState, ...
    'Refresh',@refreshDisplay,'Clear',@clearDisplay);

    function state=getState()
        if ~isvalid(fig),error('DynoForge:Closed','Dashboard window is closed.');end
        state=fig.UserData;
    end
    function setDashboard(next)
        validateDashboard(next);
        s=fig.UserData;s.Dashboard=next;s.DisplayCleared=false;
        fig.UserData=s;render(next);
    end
    function render(data)
        for j=1:9
            sig=data.Signals.(metricSpec{j,2});
            metricLabels(j).Text=sprintf('%.5g %s (%.3f s)', ...
                sig.Value(end),metricSpec{j,3},sig.Time_s(end));
        end
        for j=1:12
            sig=data.Signals.(statusNames{j});v=double(sig.Value(end));
            val=sprintf('%.5g',v);
            if strcmp(statusNames{j},'SEQ_State') && v==floor(v) && v>=0 && v<=4
                states={'IDLE','READY','RUNNING','STOPPING','FAULT'};
                val=sprintf('%d (%s)',v,states{v+1});
            elseif strcmp(statusNames{j},'ALM_Level')
                levels={'NORMAL','ADVISORY','WARNING','CRITICAL'};
                val=sprintf('%d (%s)',v,levels{v+1});
            end
            statusLabels(j).Text=val;
        end
        s=data.Signals;
        code=round(double(s.ALM_Code.Value(end)));
        level=round(double(s.ALM_Level.Value(end)));
        levels={'NORMAL','ADVISORY','WARNING','CRITICAL'};
        alarmLabels(1).Text=sprintf('LEVEL %d | %s | CODE %d',level,levels{level+1},code);
        alarmLabels(1).FontColor=levelColor(level);
        bitNames={'Sensor quality warning','Invalid calibration parameters', ...
            'Calibration incomplete','Shutdown requested'};
        bitValues=[1 2 4 8];
        for j=1:4
            active=bitand(uint16(code),uint16(bitValues(j)))~=0;
            if active, word='ACTIVE';c=[0.73 0.14 0.13];
            else,word='inactive';c=[0.30 0.48 0.34];end
            alarmLabels(j+1).Text=sprintf('Bit %d (%d) | %s: %s', ...
                j-1,bitValues(j),bitNames{j},word);
            alarmLabels(j+1).FontColor=c;
        end
        alarmLabels(6).Text=sprintf('Sensor alarm: %d | Calibration alarm: %d', ...
            s.ALM_Sensor.Value(end),s.ALM_Calibration.Value(end));
        alarmLabels(7).Text=sprintf('Shutdown alarm: %d | Alarm active: %d', ...
            s.ALM_Shutdown.Value(end),s.ALM_Active.Value(end));
        alarmLabels(8).Text=sprintf('Calibration complete: %d | Parameters valid: %d', ...
            s.CAL_Calibration_Complete.Value(end),s.CAL_All_Params_Valid.Value(end));
        alarmLabels(9).Text='DESKTOP SIMULATION ONLY | HARDWARE / CALIBRATION NOT VERIFIED';
        alarmLabels(9).FontSize=10;alarmLabels(9).FontColor=[0.65 0.27 0.12];
        for j=1:3
            sig=s.(plotSpec{j,1});cla(axesList(j));
            plot(axesList(j),sig.Time_s,sig.Value,'LineWidth',1.4);
            grid(axesList(j),'on');
        end
        state=fig.UserData;state.DisplayCleared=false;fig.UserData=state;
        statusLabel.Text=sprintf('DESKTOP | Run %d | Refresh %d | UNCALIBRATED', ...
            state.RunCount,state.RefreshCount);
        drawnow limitrate;
    end
    function refreshDisplay(~,~)
        if ~isvalid(fig),return;end
        s=fig.UserData;s.RefreshCount=s.RefreshCount+1;fig.UserData=s;
        render(s.Dashboard);
    end
    function clearDisplay(~,~)
        if ~isvalid(fig),return;end
        for j=1:9,metricLabels(j).Text='--';end
        for j=1:12,statusLabels(j).Text='--';end
        for j=1:9,alarmLabels(j).Text='--';end
        for j=1:3,cla(axesList(j));grid(axesList(j),'on');end
        s=fig.UserData;s.DisplayCleared=true;fig.UserData=s;
        statusLabel.Text='DISPLAY CLEARED | Model unchanged';
    end
    function runSimulation(~,~)
        runBtn.Enable='off';refreshBtn.Enable='off';clearBtn.Enable='off';
        cleanup=onCleanup(@restoreButtons); %#ok<NASGU>
        statusLabel.Text='Running 0.20 s desktop simulation...';drawnow;
        try
            model='ME486C_Dyno_DAQ_Quality_Development';
            load_system(model);
            assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
                'Model simulation must be stopped.');
            assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
                'Normal simulation mode required.');
            cmds={'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
            for j=1:numel(cmds)
                path=[model '/' cmds{j}];
                assert(getSimulinkBlockHandle(path)~=-1 && ...
                    strcmp(strtrim(get_param(path,'Value')),'0'), ...
                    'Operator command not zero: %s',cmds{j});
            end
            input=Simulink.SimulationInput(model);
            input=input.setModelParameter('StopTime','0.20', ...
                'SimulationMode','normal','ReturnWorkspaceOutputs','on');
            out=sim(input);
            next=DynoForge_Data_Adapter(out);
            validateDashboard(next);
            s=fig.UserData;s.RunCount=s.RunCount+1;s.LastError='';
            fig.UserData=s;setDashboard(next);
            fprintf('PASS | DESKTOP_RUN %d (39 logs, alarm consistency checked)\n',s.RunCount);
        catch ME
            s=fig.UserData;s.LastError=ME.message;fig.UserData=s;
            statusLabel.Text='RUN FAILED | Last valid snapshot preserved';
            fprintf('FAIL | DESKTOP_RUN: %s\n',ME.message);
            uialert(fig,ME.message,'Offline simulation failed');
        end
        function restoreButtons()
            if isvalid(fig)
                runBtn.Enable='on';refreshBtn.Enable='on';clearBtn.Enable='on';
            end
        end
    end
end

function c=levelColor(level)
colors={[0.20 0.46 0.25],[0.56 0.43 0.13], ...
    [0.73 0.40 0.10],[0.75 0.13 0.12]};
c=colors{level+1};
end

function validateDashboard(D)
assert(isstruct(D) && isfield(D,'Signals') && ...
    isfield(D,'Source') && strcmp(D.Source,'SIMULINK_DESKTOP_SIMULATION') && ...
    isfield(D,'HardwareVerified') && isequal(D.HardwareVerified,false) && ...
    isfield(D,'SensorCalibrationVerified') && isequal(D.SensorCalibrationVerified,false) && ...
    isfield(D,'LogCount') && D.LogCount==39, ...
    'Expected validated uncalibrated 39-log desktop simulation data.');
required={'ENG_Force_N','ENG_RPM','ENG_Temp_In_C','ENG_Temp_Out_C', ...
    'ENG_Flow_Lmin','ENG_Torque_Nm','ENG_Power_kW','ENG_Delta_T_C', ...
    'ENG_Cooling_Power_kW','SEQ_State','SEQ_Active','SEQ_Ready', ...
    'SEQ_Fault_Latched','SEQ_Permit','SQ_All_Sensors_OK', ...
    'SQ_Quality_Fault_Code','SQ_Quality_Warning', ...
    'CAL_All_Params_Valid','CAL_Calibration_Complete', ...
    'ALM_Level','ALM_Code','ALM_Active','ALM_Sensor', ...
    'ALM_Calibration','ALM_Shutdown'};
for k=1:numel(required)
    assert(isfield(D.Signals,required{k}),'Missing %s',required{k});
    s=D.Signals.(required{k});
    assert(isfield(s,'Time_s') && isfield(s,'Value') && ...
        isnumeric(s.Value) && isnumeric(s.Time_s) && ...
        isvector(s.Value) && isvector(s.Time_s) && ...
        ~isempty(s.Value) && numel(s.Value)==numel(s.Time_s) && ...
        all(isfinite(s.Value(:))) && all(isfinite(s.Time_s(:))) && ...
        all(diff(s.Time_s(:))>0),'Invalid %s',required{k});
end
% Check the latest time-aligned alarm snapshot against verified source logic.
names={'ALM_Code','ALM_Level','ALM_Active','ALM_Sensor', ...
    'ALM_Calibration','ALM_Shutdown','CAL_All_Params_Valid', ...
    'CAL_Calibration_Complete'};
refTime=D.Signals.ALM_Code.Time_s(end);
for k=1:numel(names)
    s=D.Signals.(names{k});
    assert(abs(double(s.Time_s(end))-double(refTime))<1e-9, ...
        'Alarm latest timestamp mismatch: %s',names{k});
    assert(ismember(double(s.Value(end)),[0 1]) || ...
        ismember(names{k},{'ALM_Code','ALM_Level'}), ...
        'Invalid boolean signal: %s',names{k});
end
s=D.Signals;
sensor=double(s.ALM_Sensor.Value(end));
shutdown=double(s.ALM_Shutdown.Value(end));
valid=double(s.CAL_All_Params_Valid.Value(end));
complete=double(s.CAL_Calibration_Complete.Value(end));
code=double(s.ALM_Code.Value(end));
level=double(s.ALM_Level.Value(end));
expectedCode=sensor+2*(~logical(valid))+4*(~logical(complete))+8*shutdown;
expectedLevel=0;
if ~complete,expectedLevel=1;end
if sensor || ~valid,expectedLevel=2;end
if shutdown,expectedLevel=3;end
assert(isequal(code,double(expectedCode)) && ...
    isequal(level,double(expectedLevel)) && ...
    isequal(double(s.ALM_Calibration.Value(end)),double(~valid || ~complete)) && ...
    isequal(double(s.ALM_Active.Value(end)),double(code~=0)), ...
    'Alarm code/level/category inconsistency in dashboard snapshot.');
assert(all(ismember(double(s.SEQ_State.Value(:)),0:4)) && ...
    all(ismember(double(s.ALM_Level.Value(:)),0:3)) && ...
    all(ismember(double(s.ALM_Code.Value(:)),0:15)), ...
    'Invalid state/alarm values.');
if s.SEQ_State.Value(end)==4
    assert(s.SEQ_Ready.Value(end)==0 && ...
        s.SEQ_Fault_Latched.Value(end)==1, ...
        'FAULT snapshot conflicts with READY or fault latch.');
end
end
