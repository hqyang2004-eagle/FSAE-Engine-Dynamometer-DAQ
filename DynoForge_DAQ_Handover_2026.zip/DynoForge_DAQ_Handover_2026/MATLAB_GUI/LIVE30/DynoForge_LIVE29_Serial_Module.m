function out = DynoForge_LIVE29_Serial_Module(action)
% LIVE-29 Serial Module V1
% Arduino synthetic data; physical sensors NOT verified.
persistent s rxBuffer data counters t0 running
if isempty(running)
    running = false;
    s = [];
    rxBuffer = uint8([]);
    data = zeros(0,5);
    counters = [0 0 0];
    t0 = [];
end
if nargin < 1
    action = 'get';
end
switch lower(char(action))
    case 'start'
        if running
            error('Receiver already running.');
        end
        if ~isempty(s)
            try, configureCallback(s,'off'); catch, end
            try, delete(s); catch, end
            s = [];
        end
        rxBuffer = uint8([]);
        data = zeros(0,5);
        counters = [0 0 0];
        t0 = tic;
        try
            s = serialport('COM5',115200,'Timeout',0.2);
            flush(s);
            running = true;
            configureCallback(s,'byte',1,@receiveBytes);
        catch ME
            running = false;
            if ~isempty(s)
                try, configureCallback(s,'off'); catch, end
                try, delete(s); catch, end
            end
            s = [];
            rethrow(ME);
        end
        out = getStatus();
    case 'stop'
        running = false;
        if ~isempty(s)
            try, configureCallback(s,'off'); catch, end
            try, delete(s); catch, end
            s = [];
        end
        out = getStatus();
    case 'get'
        out = getStatus();
    case 'reset'
        if running
            error('Stop receiver before reset.');
        end
        rxBuffer = uint8([]);
        data = zeros(0,5);
        counters = [0 0 0];
        t0 = [];
        out = getStatus();
    otherwise
        error('Unknown action: %s',char(action));
end

    function receiveBytes(src,~)
        if ~running
            return;
        end
        try
            n = src.NumBytesAvailable;
            if n <= 0
                return;
            end
            incoming = read(src,n,'uint8');
            rxBuffer = [rxBuffer uint8(incoming(:).')];
            while numel(rxBuffer) >= 2
                if rxBuffer(1) ~= 170 || rxBuffer(2) ~= 85
                    rxBuffer(1) = [];
                    counters(3) = counters(3)+1;
                    continue;
                end
                if numel(rxBuffer) < 11
                    break;
                end
                frame = rxBuffer(1:11);
                expected = mod(sum(double(frame(3:10))),256);
                if double(frame(11)) ~= expected
                    counters(2) = counters(2)+1;
                    rxBuffer(1) = [];
                    continue;
                end
                p = double(frame(3:10));
                rpm = p(1)*256+p(2);
                torque = (p(3)*256+p(4))/10;
                rawTemp = uint16(p(5)*256+p(6));
                temp = double(typecast(rawTemp,'int16'))/10;
                flow = (p(7)*256+p(8))/10;
                data(end+1,:) = [toc(t0),rpm,torque,temp,flow];
                counters(1) = counters(1)+1;
                rxBuffer(1:11) = [];
            end
        catch ME
            counters(3) = counters(3)+1;
            warning('LIVE29:SerialRead','%s',ME.message);
        end
    end

    function st = getStatus()
        st = struct();
        st.Running = running;
        st.Port = 'COM5';
        st.Baud = 115200;
        st.ValidFrames = counters(1);
        st.ChecksumErrors = counters(2);
        st.DiscardedOrReadErrors = counters(3);
        st.PendingBytes = numel(rxBuffer);
        st.Data = data;
        st.SyntheticData = true;
        st.SensorHardwareVerified = false;
    end
end
