function DynoForge_Calibration_Test_Report()
% DynoForge Step 10.9 offline UI test report.
figs=findall(groot,'Type','figure');
for i=1:numel(figs)
    if isappdata(figs(i),'DynoForgeCalibrationReport')
        reportFcn=getappdata(figs(i),'DynoForgeCalibrationReport');
        reportFcn();
        return;
    end
end
fprintf('STEP 10.9 NOT TESTED: Open DynoForge_Calibration_Display first.\n');
end
