function app = DynoForge_Calibration_Display()
% DynoForge Step 10.9 - OFFLINE calibration status monitor.
% Does not read/write Simulink, change calibration, or access hardware.

names = {'LOAD CELL','RPM','INLET TEMPERATURE','OUTLET TEMPERATURE','FLOW'};
counts = zeros(1,6);
fig = uifigure('Name','DynoForge | Step 10.9 Calibration Monitor', ...
    'Position',[140 130 980 650],'Color',[0.08 0.10 0.14]);
fig.CloseRequestFcn = @(~,~) delete(fig);
root = uigridlayout(fig,[5 1]);
root.RowHeight = {55,65,270,150,'1x'};
root.Padding = [16 14 16 14];
root.RowSpacing = 10;
root.BackgroundColor = [0.08 0.10 0.14];
header = uilabel(root,'Text','DYNOFORGE | CALIBRATION STATUS MONITOR', ...
    'FontSize',21,'FontWeight','bold','FontColor',[0.95 0.97 1]);
header.Layout.Row = 1;
buttons = uigridlayout(root,[1 6]);
buttons.Layout.Row = 2;
buttons.ColumnWidth = {'1x','1x','1x','1x','1x','1x'};
buttons.BackgroundColor = [0.08 0.10 0.14];
labels = {'VALID / UNCONFIRMED','INVALID LOAD CELL','MULTIPLE INVALID','SIMULATED COMPLETE','UNKNOWN','RUN ALL TESTS'};
for i=1:6
    idx=i;
    uibutton(buttons,'push','Text',labels{i},'FontSize',10, ...
        'ButtonPushedFcn',@(~,~)runCase(idx));
end
panel = uipanel(root,'Title','CALIBRATION CHANNEL STATUS', ...
    'BackgroundColor',[0.12 0.15 0.20], ...
    'ForegroundColor',[0.95 0.97 1]);
panel.Layout.Row = 3;
grid = uigridlayout(panel,[7 2]);
grid.RowHeight = repmat({'1x'},1,7);
grid.ColumnWidth = {'1x','1x'};
grid.BackgroundColor = [0.12 0.15 0.20];
valueLabels = gobjects(1,7);
rowNames = [names {'ALL PARAMS VALID','CALIBRATION COMPLETE'}];
for i=1:7
    uilabel(grid,'Text',rowNames{i},'FontColor',[0.76 0.83 0.92], ...
        'FontSize',13,'FontWeight','bold');
    valueLabels(i) = uilabel(grid,'Text','UNKNOWN', ...
        'FontColor',[1 0.73 0.30],'FontSize',13,'FontWeight','bold');
end
info = uipanel(root,'Title','FAULT CODE / SAFETY', ...
    'BackgroundColor',[0.12 0.15 0.20], ...
    'ForegroundColor',[0.95 0.97 1]);
info.Layout.Row = 4;
ig = uigridlayout(info,[3 1]);
ig.BackgroundColor = [0.12 0.15 0.20];
faultLabel = uilabel(ig,'Text','CAL_Calibration_Fault_Code: UNKNOWN', ...
    'FontColor',[1 0.73 0.30],'FontWeight','bold');
modeLabel = uilabel(ig,'Text','OFFLINE DEMO | SIMULINK DISCONNECTED', ...
    'FontColor',[1 0.73 0.30],'FontWeight','bold');
uilabel(ig,'Text','Physical calibration: NOT VERIFIED | Calibration_Confirmed remains 0 in main model', ...
    'FontColor',[1 0.73 0.30]);
logBox = uitextarea(root,'Editable','off','Value', ...
    {'[INFO] Step 10.9 offline monitor initialized'; ...
     '[SAFE] No model changes or hardware access'; ...
     '[SAFE] Demo complete is never physical calibration confirmation'});
logBox.Layout.Row = 5;

app = struct('Figure',fig,'RunCase',@runCase,'GetReport',@getReport);
setappdata(fig,'DynoForgeCalibrationReport',@printReport);
fprintf('\n===== STEP 10.9 CALIBRATION DISPLAY =====\n');
fprintf('PASS | Offline monitor created\n');
fprintf('PASS | Physical calibration NOT VERIFIED\n');
fprintf('No Simulink writes or hardware access.\n');
fprintf('=========================================\n');

    function runCase(idx)
        switch idx
            case 1
                flags = true(1,5); confirmed = false; code = 0;
            case 2
                flags = [false true true true true]; confirmed = false; code = 1;
            case 3
                flags = [false true false true false]; confirmed = false; code = 1+4+16;
            case 4
                flags = true(1,5); confirmed = true; code = 0;
            case 5
                flags = []; confirmed = false; code = NaN;
            case 6
                for j=1:5
                    runCase(j);
                end
                counts(6)=counts(6)+1;
                appendLog('[TEST] All five scenarios executed');
                return;
        end
        counts(idx)=counts(idx)+1;
        if isempty(flags)
            for j=1:7
                valueLabels(j).Text='UNKNOWN';
                valueLabels(j).FontColor=[1 0.73 0.30];
            end
            faultLabel.Text='CAL_Calibration_Fault_Code: UNKNOWN';
        else
            for j=1:5
                if flags(j)
                    valueLabels(j).Text='VALID (DEMO)';
                    valueLabels(j).FontColor=[0.35 0.85 0.55];
                else
                    valueLabels(j).Text='INVALID (DEMO)';
                    valueLabels(j).FontColor=[1 0.35 0.35];
                end
            end
            allValid = all(flags);
            if allValid
                valueLabels(6).Text='YES (DEMO)';
                valueLabels(6).FontColor=[0.35 0.85 0.55];
            else
                valueLabels(6).Text='NO (DEMO)';
                valueLabels(6).FontColor=[1 0.35 0.35];
            end
            if allValid && confirmed
                valueLabels(7).Text='YES (SIMULATED ONLY)';
                valueLabels(7).FontColor=[1 0.73 0.30];
            else
                valueLabels(7).Text='NO';
                valueLabels(7).FontColor=[1 0.73 0.30];
            end
            faultLabel.Text=sprintf('CAL_Calibration_Fault_Code: %d (DEMO)',code);
        end
        appendLog(sprintf('[DEMO] %s | No physical calibration performed',labels{idx}));
    end

    function appendLog(msg)
        v=logBox.Value;
        if ischar(v), v={v}; end
        v{end+1}=msg;
        logBox.Value=v;
    end

    function r=getReport()
        r=counts;
    end

    function printReport()
        fprintf('\n===== STEP 10.9 OFFLINE VERIFICATION =====\n');
        testNames={'VALID_UNCONFIRMED','INVALID_LOAD_CELL', ...
            'MULTIPLE_INVALID','SIMULATED_COMPLETE','UNKNOWN'};
        ok=true;
        for j=1:5
            if counts(j)>0
                fprintf('PASS | %s: %d test(s)\n',testNames{j},counts(j));
            else
                fprintf('NOT TESTED | %s\n',testNames{j});
                ok=false;
            end
        end
        if ok
            fprintf('STEP 10.9 OFFLINE DISPLAY TEST PASSED\n');
        else
            fprintf('STEP 10.9 INCOMPLETE: Run all five scenarios\n');
        end
        fprintf('Simulink integration: NOT TESTED\n');
        fprintf('Physical calibration: NOT VERIFIED\n');
        fprintf('==========================================\n');
    end
end
