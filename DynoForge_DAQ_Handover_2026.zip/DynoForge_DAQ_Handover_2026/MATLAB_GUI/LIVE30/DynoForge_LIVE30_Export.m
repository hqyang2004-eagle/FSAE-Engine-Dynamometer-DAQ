function result = DynoForge_LIVE30_Export(st)
% Export stopped synthetic acquisition to CSV and MAT.
% Does not reset or modify receiver data.
assert(~st.Running,'Stop acquisition before export.');
assert(~isempty(st.Data),'No data to export.');
D = st.Data;
assert(size(D,2)==5,'Expected five columns.');
assert(size(D,1)==st.ValidFrames,'Frame count mismatch.');
assert(all(isfinite(D(:))),'Nonfinite data detected.');
assert(all(diff(D(:,1))>0),'Invalid timestamps.');

root = 'C:\DynoForge_Test';
dataDir = fullfile(root,'LIVE30','Data');
if ~isfolder(dataDir)
    mkdir(dataDir);
end

T = array2table(D,'VariableNames', ...
    {'Time_s','RPM','Torque_Nm','Temp_C','Flow_Lmin'});

stamp = char(string(datetime('now','Format','yyyyMMdd_HHmmss_SSS')));
base = fullfile(dataDir,['DynoForge_LIVE30_' stamp]);
csvPath = [base '.csv'];
matPath = [base '.mat'];
assert(~isfile(csvPath) && ~isfile(matPath), ...
    'Export filename already exists.');

metadata = struct();
metadata.Source = 'Arduino_Simulink_Synthetic';
metadata.SensorHardwareVerified = false;
metadata.ExportTime = datetime('now');
metadata.ValidFrames = st.ValidFrames;
metadata.ChecksumErrors = st.ChecksumErrors;
metadata.DiscardedOrReadErrors = st.DiscardedOrReadErrors;

writetable(T,csvPath);
save(matPath,'T','metadata');

R = readtable(csvPath);
M = load(matPath);
assert(isequal(size(R),size(T)) && ...
    all(isfinite(R{:,:}),'all') && ...
    all(abs(R{:,:}-T{:,:}) <= 1e-9,'all'), ...
    'CSV verification failed.');
assert(isequaln(M.T{:,:},T{:,:}),'MAT verification failed.');

result = struct();
result.Success = true;
result.Rows = height(T);
result.CSV = csvPath;
result.MAT = matPath;
end
