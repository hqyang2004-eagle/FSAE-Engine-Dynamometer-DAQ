function DynoForge_Signal_Quality_Test_Report()
% DynoForge Step 10.8 - read-only report for the open offline demo.
    figs=findall(groot,'Type','figure');
    for i=1:numel(figs)
        if isappdata(figs(i),'DynoForgeSQGetReport')
            fn=getappdata(figs(i),'DynoForgeSQGetReport');
            fn();
            return;
        end
    end
    fprintf('STEP 10.8 NOT TESTED: Open DynoForge_Signal_Quality_Display first.\n');
end
