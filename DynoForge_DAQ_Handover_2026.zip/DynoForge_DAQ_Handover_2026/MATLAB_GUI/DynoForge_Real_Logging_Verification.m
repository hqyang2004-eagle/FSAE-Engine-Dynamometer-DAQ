function report = DynoForge_Real_Logging_Verification()
% DynoForge Step 10.14B-3: controlled desktop simulation and log inspection.
% Does not edit/save the model, change commands, or deploy hardware.
model = 'ME486C_Dyno_DAQ_Quality_Development';
report = struct('PreflightPassed',false,'SimulationPassed',false, ...
    'LogCount',0,'ValidLogCount',0,'EngineeringLogCount',0, ...
    'Output',[],'Errors',{{}});
fprintf('\n===== STEP 10.14B-3 REAL LOGGING VERIFICATION =====\n');
load_system(model);
assert(strcmp(get_param(model,'SimulationStatus'),'stopped'), ...
    'Simulation must be stopped before this test.');
assert(strcmp(get_param(model,'SimulationMode'),'normal'), ...
    'Model must be in Normal simulation mode. Current mode: %s',get_param(model,'SimulationMode'));
assert(strcmp(get_param(model,'Dirty'),'off'), ...
    'Model has unsaved changes. Save/review the model first.');
commands = {'SEQ_Start_Command','SEQ_Stop_Command','SEQ_Reset_Command'};
for i = 1:numel(commands)
    block = [model '/' commands{i}];
    assert(getSimulinkBlockHandle(block) ~= -1,'Missing %s',block);
    val = strtrim(get_param(block,'Value'));
    assert(strcmp(val,'0'),'Unsafe command: %s = %s',commands{i},val);
end
logs = find_system(model,'SearchDepth',1,'BlockType','ToWorkspace');
assert(numel(logs)==39,'Expected 39 top-level To Workspace blocks; found %d.',numel(logs));
names = cellfun(@(p)get_param(p,'VariableName'),logs,'UniformOutput',false);
assert(numel(unique(names))==39,'Duplicate logging names detected.');
for i = 1:numel(logs)
    assert(strcmp(get_param(logs{i},'SaveFormat'),'Timeseries'), ...
        'Non-Timeseries logger: %s',names{i});
    p = get_param(logs{i},'PortHandles');
    assert(~isempty(p.Inport) && get_param(p.Inport(1),'Line')~=-1, ...
        'Disconnected logger: %s',names{i});
end
requiredEng = {'ENG_Force_N','ENG_RPM','ENG_Temp_In_C', ...
    'ENG_Temp_Out_C','ENG_Flow_Lmin','ENG_Torque_Nm', ...
    'ENG_Power_kW','ENG_Delta_T_C','ENG_Cooling_Power_kW'};
assert(all(ismember(requiredEng,names)),'Missing required ENG loggers.');
report.PreflightPassed = true;
fprintf('PASS | PRECHECK (39 logs, Normal mode, commands zero)\n');

% SimulationInput overrides only StopTime and ReturnWorkspaceOutputs for this run.
% It does not write changes into the saved model.
try
    in = Simulink.SimulationInput(model);
    in = in.setModelParameter('StopTime','0.20', ...
        'ReturnWorkspaceOutputs','on');
    fprintf('INFO | Starting 0.20 s Normal-mode desktop simulation...\n');
    out = sim(in);
    report.Output = out;
    report.SimulationPassed = true;
    fprintf('PASS | SIMULATION_COMPLETED\n');
catch ME
    report.Errors{end+1} = ME.message;
    fprintf('FAIL | SIMULATION_FAILED\n%s\n',ME.message);
    fprintf('No hardware deployment was requested. Do not change hardware or safety settings to force a pass.\n');
    fprintf('STEP 10.14B-3 NOT PASSED\n');
    return;
end

% Inspect returned SimulationOutput (not stale base-workspace variables).
outputNames = out.who;
report.LogCount = numel(intersect(names,outputNames));
for i = 1:numel(names)
    name = names{i};
    if ~ismember(name,outputNames)
        fprintf('FAIL | %-30s MISSING\n',name);
        continue;
    end
    ts = out.get(name);
    if ~isa(ts,'timeseries')
        fprintf('FAIL | %-30s NOT_TIMESERIES\n',name);
        continue;
    end
    t = double(ts.Time(:));
    d = ts.Data;
    valid = ~isempty(t) && numel(t)==numel(d) && ...
        all(isfinite(t)) && all(diff(t)>0) && ...
        (isnumeric(d) || islogical(d)) && all(isfinite(double(d(:))));
    if valid
        report.ValidLogCount = report.ValidLogCount+1;
        if ismember(name,requiredEng)
            report.EngineeringLogCount = report.EngineeringLogCount+1;
        end
        fprintf('PASS | %-30s samples=%d\n',name,numel(t));
    else
        fprintf('FAIL | %-30s EMPTY/SHAPE/TIME/NONFINITE\n',name);
    end
end
fprintf('\n===== STEP 10.14B-3 SUMMARY =====\n');
fprintf('Logs returned: %d / 39\n',report.LogCount);
fprintf('Valid logs: %d / 39\n',report.ValidLogCount);
fprintf('Valid ENG logs: %d / 9\n',report.EngineeringLogCount);
if report.LogCount==39 && report.ValidLogCount==39 && report.EngineeringLogCount==9
    fprintf('STEP 10.14B-3 LOGGING VERIFICATION PASSED\n');
else
    fprintf('STEP 10.14B-3 REQUIRES REVIEW\n');
end
fprintf('Sensor accuracy/calibration: NOT VERIFIED\n');
fprintf('Hardware deployment: NOT REQUESTED\n');
fprintf('====================================\n');
end
