function app = DynoForge_Command_Interface()
% DynoForge Step 10.4 - Offline Operator Command Interface
% Standalone GUI; no Simulink writes, simulation starts, or hardware access.

    fig = uifigure('Name','DynoForge | Step 10.4 Operator Controls', ...
        'Position',[150 150 760 470], 'Color',[0.08 0.10 0.14]);
    fig.CloseRequestFcn = @closeWindow;

    root = uigridlayout(fig,[5 1]);
    root.RowHeight = {55, 115, 60, '1x', 28};
    root.Padding = [18 16 18 16];
    root.RowSpacing = 10;
    root.BackgroundColor = [0.08 0.10 0.14];

    header = uilabel(root,'Text','DYNOFORGE  |  OFFLINE COMMAND TEST', ...
        'FontSize',20,'FontWeight','bold','FontColor',[0.94 0.97 1]);
    header.Layout.Row = 1;

    buttons = uigridlayout(root,[1 3]);
    buttons.Layout.Row = 2;
    buttons.ColumnWidth = {'1x','1x','1x'};
    buttons.ColumnSpacing = 12;
    buttons.BackgroundColor = [0.08 0.10 0.14];

    startBtn = uibutton(buttons,'push','Text','START REQUEST', ...
        'FontWeight','bold','FontSize',15, ...
        'BackgroundColor',[0.12 0.52 0.32], 'FontColor',[1 1 1], ...
        'ButtonPushedFcn',@(~,~)requestCommand('START'));
    startBtn.Layout.Column = 1;
    stopBtn = uibutton(buttons,'push','Text','STOP REQUEST', ...
        'FontWeight','bold','FontSize',15, ...
        'BackgroundColor',[0.75 0.39 0.12], 'FontColor',[1 1 1], ...
        'ButtonPushedFcn',@(~,~)requestCommand('STOP'));
    stopBtn.Layout.Column = 2;
    resetBtn = uibutton(buttons,'push','Text','RESET REQUEST', ...
        'FontWeight','bold','FontSize',15, ...
        'BackgroundColor',[0.30 0.38 0.49], 'FontColor',[1 1 1], ...
        'ButtonPushedFcn',@(~,~)requestCommand('RESET'));
    resetBtn.Layout.Column = 3;

    status = uilabel(root, 'Text','Last request: NONE | Simulink: DISCONNECTED', ...
        'FontSize',13,'FontWeight','bold','FontColor',[1 0.76 0.35]);
    status.Layout.Row = 3;

    logBox = uitextarea(root,'Editable','off', ...
        'Value',{'[INFO] Step 10.4 offline command test initialized'; ...
                 '[SAFE] No Simulink parameter writes or hardware actions'});
    logBox.Layout.Row = 4;

    footer = uilabel(root,'Text', ...
        'Command requests only. Not an emergency-stop device.', ...
        'FontSize',11,'FontColor',[0.66 0.73 0.83]);
    footer.Layout.Row = 5;

    requests = strings(0,1);
    counts = zeros(1,3);
    app = struct('Figure',fig,'StartButton',startBtn, ...
        'StopButton',stopBtn,'ResetButton',resetBtn, ...
        'StatusLabel',status,'Log',logBox);

    fprintf('\n===== STEP 10.4 OFFLINE COMMAND INTERFACE =====\n');
    fprintf('PASS | Window created\n');
    fprintf('PASS | START / STOP / RESET callbacks installed\n');
    fprintf('PASS | Simulink disconnected; no hardware access\n');
    fprintf('Click each button once, then run: DynoForge_Command_Test_Report\n');

    % Put a read-only report callback in the figure for Command Window use.
    setappdata(fig,'DynoForgeReport',@report);

    function requestCommand(command)
        switch command
            case 'START'
                counts(1) = counts(1)+1;
            case 'STOP'
                counts(2) = counts(2)+1;
            case 'RESET'
                counts(3) = counts(3)+1;
        end
        requests(end+1,1) = string(command);
        stamp = datestr(now,'HH:MM:SS');
        msg = sprintf('[%s] %s request recorded | OFFLINE ONLY',stamp,command);
        logBox.Value = [cellstr(logBox.Value); {msg}];
        status.Text = sprintf('Last request: %s | Simulink: DISCONNECTED',command);
        fprintf('%s\n',msg);
    end

    function report()
        fprintf('\n===== STEP 10.4 BUTTON VERIFICATION =====\n');
        names = {'START','STOP','RESET'};
        for k = 1:3
            if counts(k)>0
                fprintf('PASS | %s button: %d request(s)\n',names{k},counts(k));
            else
                fprintf('PENDING | %s button not clicked\n',names{k});
            end
        end
        fprintf('Recorded request sequence: %s\n',strjoin(cellstr(requests),' -> '));
        if all(counts>0)
            fprintf('STEP 10.4 OFFLINE BUTTON TEST PASSED\n');
        else
            fprintf('STEP 10.4 TEST INCOMPLETE\n');
        end
        fprintf('Simulink and hardware integration: NOT TESTED\n');
        fprintf('=========================================\n');
    end

    function closeWindow(~,~)
        if isvalid(fig)
            delete(fig);
        end
    end
end
