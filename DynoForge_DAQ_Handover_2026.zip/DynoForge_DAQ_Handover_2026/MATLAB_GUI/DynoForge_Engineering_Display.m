function app = DynoForge_Engineering_Display()
% DynoForge Step 10.7 - offline engineering calculations display.
% No Simulink or hardware access. Torque arm = 12.000 in = 0.3048 m.
arm = 0.3048;
fig = uifigure('Name','DynoForge | Step 10.7 Engineering Display', ...
    'Position',[120 120 930 590], 'Color',[0.08 0.10 0.14]);
g = uigridlayout(fig,[6 4]);
g.RowHeight = {58,54,75,80,'1x',35};
g.ColumnWidth = {'1x','1x','1x','1x'};
g.Padding = [18 15 18 15]; g.RowSpacing=12; g.ColumnSpacing=12;
g.BackgroundColor=[0.08 0.10 0.14];
titleLabel = uilabel(g,'Text','DYNOFORGE | ENGINEERING CALCULATIONS', ...
    'FontSize',21,'FontWeight','bold','FontColor',[1 1 1]);
titleLabel.Layout.Row=1; titleLabel.Layout.Column=[1 4];
labels = {'FORCE (N)','RPM','TORQUE (N*m)','POWER (kW)'};
valueLabels = cell(1,4);
for k=1:4
    panel = uipanel(g,'Title',labels{k},'BackgroundColor',[0.13 0.17 0.23], ...
        'ForegroundColor',[0.92 0.96 1]);
    panel.Layout.Row=3;panel.Layout.Column=k;
    valueLabels{k}=uilabel(panel,'Text','--','Position',[12 9 185 34], ...
        'FontSize',22,'FontWeight','bold','FontColor',[1 1 1]);
end
forceField = uieditfield(g,'numeric','Value',500,'Limits',[-Inf Inf]);
forceField.Layout.Row=2;forceField.Layout.Column=1;
rpmField = uieditfield(g,'numeric','Value',3000,'Limits',[-Inf Inf]);
rpmField.Layout.Row=2;rpmField.Layout.Column=2;
statusLabel=uilabel(g,'Text','OFFLINE DEMO | NOT CALIBRATED', ...
    'FontWeight','bold','FontColor',[1 .7 .2]);
statusLabel.Layout.Row=2;statusLabel.Layout.Column=[3 4];
btn1=uibutton(g,'Text','CALCULATE','ButtonPushedFcn',@(~,~)runCase('CALCULATE',forceField.Value,rpmField.Value));
btn1.Layout.Row=4;btn1.Layout.Column=1;
btn2=uibutton(g,'Text','ZERO RPM','ButtonPushedFcn',@(~,~)runCase('ZERO_RPM',500,0));
btn2.Layout.Row=4;btn2.Layout.Column=2;
btn3=uibutton(g,'Text','INVALID INPUT','ButtonPushedFcn',@(~,~)runInvalid());
btn3.Layout.Row=4;btn3.Layout.Column=3;
btn4=uibutton(g,'Text','RUN ALL TESTS','ButtonPushedFcn',@(~,~)runAll());
btn4.Layout.Row=4;btn4.Layout.Column=4;
logBox=uitextarea(g,'Editable','off','FontName','Consolas', ...
    'Value',{'[INFO] Offline engineering display initialized'; ...
    '[SAFE] No Simulink writes, simulation, or hardware access'});
logBox.Layout.Row=5;logBox.Layout.Column=[1 4];
footer=uilabel(g,'Text','Demo input limits: Force 0-2000 N; RPM 0-11000. Limits are for UI tests only.', ...
    'FontColor',[.65 .75 .85]);
footer.Layout.Row=6;footer.Layout.Column=[1 4];
results = struct('NORMAL',false,'ZERO_RPM',false,'NEGATIVE_RPM',false, ...
    'NAN',false,'INF',false,'OUT_OF_RANGE',false,'CONSISTENCY',false);
setappdata(fig,'DynoForgeEngineeringReport',@report);
app=fig;
fprintf('\n===== STEP 10.7 ENGINEERING DISPLAY =====\n');
fprintf('PASS | Engineering display window created\n');
fprintf('PASS | Offline calculations only; no hardware access\n');
fprintf('Run ALL TESTS, then DynoForge_Engineering_Test_Report\n');
fprintf('=========================================\n');
    function appendLog(s)
        old=logBox.Value;
        if ischar(old),old={old};end
        logBox.Value=[old(:);{s}];
    end
    function [ok,tau,omega,power,reason]=compute(F,R)
        tau=NaN;omega=NaN;power=NaN;reason='';ok=false;
        if ~isnumeric(F)||~isnumeric(R)||~isscalar(F)||~isscalar(R)||~isfinite(F)||~isfinite(R)
            reason='NONFINITE_OR_NONNUMERIC';return
        end
        if F<0||R<0
            reason='NEGATIVE_INPUT';return
        end
        if F>2000||R>11000
            reason='OUT_OF_DEMO_RANGE';return
        end
        tau=F*arm;omega=2*pi*R/60;power=tau*omega/1000;
        ok=true;reason='VALID_DEMO';
    end
    function runCase(name,F,R)
        [ok,tau,omega,power,reason]=compute(F,R);
        if ok
            valueLabels{1}.Text=sprintf('%.2f',F);
            valueLabels{2}.Text=sprintf('%.1f',R);
            valueLabels{3}.Text=sprintf('%.3f',tau);
            valueLabels{4}.Text=sprintf('%.3f',power);
            statusLabel.Text='VALID DEMO | NOT CALIBRATED';
            statusLabel.FontColor=[.4 .85 .6];
            appendLog(sprintf('[DEMO] %s: F=%.3f N, RPM=%.3f, torque=%.6f N*m, omega=%.6f rad/s, power=%.6f kW',name,F,R,tau,omega,power));
        else
            for j=1:4,valueLabels{j}.Text='--';end
            statusLabel.Text=['REJECTED: ' reason];
            statusLabel.FontColor=[1 .35 .35];
            appendLog(sprintf('[REJECTED] %s: %s',name,reason));
        end
    end
    function runInvalid()
        runCase('NEGATIVE_RPM',500,-100);
        runCase('NAN',NaN,1000);
        runCase('INF',Inf,1000);
        runCase('OUT_OF_RANGE',500,11001);
    end
    function runAll()
        [ok,tau,omega,p,~]=compute(500,3000);
        expectedTau=152.4;
        expectedOmega=100*pi;
        expectedP=expectedTau*expectedOmega/1000;
        results.NORMAL=ok;
        results.CONSISTENCY=ok && abs(tau-expectedTau)<1e-10 && ...
            abs(omega-expectedOmega)<1e-10 && abs(p-expectedP)<1e-10;
        [ok0,tau0,omega0,p0,~]=compute(500,0);
        results.ZERO_RPM=ok0 && tau0==152.4 && omega0==0 && p0==0;
        [okNeg,~,~,~,~]=compute(500,-1);results.NEGATIVE_RPM=~okNeg;
        [okNan,~,~,~,~]=compute(NaN,1000);results.NAN=~okNan;
        [okInf,~,~,~,~]=compute(Inf,1000);results.INF=~okInf;
        [okRange,~,~,~,~]=compute(500,11001);results.OUT_OF_RANGE=~okRange;
        runCase('NORMAL',500,3000);
        appendLog('[TEST] All seven calculation/validation assertions evaluated');
        setappdata(fig,'DynoForgeEngineeringResults',results);
        fprintf('Step 10.7: all tests executed. Run DynoForge_Engineering_Test_Report()\n');
    end
    function report()
        names=fieldnames(results);
        fprintf('\n===== STEP 10.7 OFFLINE VERIFICATION =====\n');
        for j=1:numel(names)
            if results.(names{j}),s='PASS';else,s='FAIL / NOT TESTED';end
            fprintf('%s | %s\n',s,names{j});
        end
        if all(structfun(@(v) logical(v),results))
            fprintf('STEP 10.7 OFFLINE CALCULATION TEST PASSED\n');
        else
            fprintf('STEP 10.7 INCOMPLETE / FAILED\n');
        end
        fprintf('Simulink formula equivalence: NOT VERIFIED\n');
        fprintf('Hardware/calibration: NOT TESTED\n');
        fprintf('==========================================\n');
    end
end
