function DynoForge_Engineering_Test_Report()
% Print results from the open Step 10.7 engineering display.
figs=findall(groot,'Type','figure');
for k=1:numel(figs)
    if isappdata(figs(k),'DynoForgeEngineeringReport')
        callback=getappdata(figs(k),'DynoForgeEngineeringReport');
        callback();
        return
    end
end
fprintf('STEP 10.7 NOT TESTED: Open DynoForge_Engineering_Display first.\n');
end
