function DynoForge_Sensor_Test_Report()
% Step 10.6 offline UI test report; requires open sensor display window.
figs = findall(groot,'Type','figure');
for k = 1:numel(figs)
    if isappdata(figs(k),'DynoForgeSensorReport')
        callback = getappdata(figs(k),'DynoForgeSensorReport');
        callback();
        return;
    end
end
fprintf('STEP 10.6 NOT TESTED: Open DynoForge_Sensor_Display first.\n');
end
