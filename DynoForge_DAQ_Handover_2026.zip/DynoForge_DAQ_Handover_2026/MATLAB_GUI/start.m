
clc;

mdl = 'ME486C_Dyno_DAQ_Final_Version';

Simulink.fileGenControl('set', ...
    'CacheFolder', 'C:\DynoForge_SL_Cache', ...
    'CodeGenFolder', 'C:\DynoForge_SL_CodeGen');

cd('C:\DynoForge_Test');

open_system(mdl);

