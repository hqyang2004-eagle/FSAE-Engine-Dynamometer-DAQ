function app = DynoForge_Realtime_Plot()
% DynoForge Step 10.11 - OFFLINE real-time plotting demonstration.
% No Simulink writes, hardware access, or engine control.
% Run DynoForge_Realtime_Plot_Test_Report while this window is open.

fig = uifigure('Name','DynoForge | Step 10.11 Offline Real-Time Plots', ...
    'Position',[100 80 1120 790], 'Color',[0.08 0.10 0.14]);
fig.CloseRequestFcn = @closeWindow;

root = uigridlayout(fig,[5 1]);
root.RowHeight = {48,54,'1x',110,26};
root.Padding = [16 12 16 12];
root.RowSpacing = 8;
root.BackgroundColor = [0.08 0.10 0.14];

header = uilabel(root,'Text','DYNOFORGE | STEP 10.11 - OFFLINE REAL-TIME PLOTTING', ...
    'FontSize',19,'FontWeight','bold','FontColor',[0.95 0.97 1]);
header.Layout.Row = 1;

bar = uigridlayout(root,[1 6]);
bar.Layout.Row = 2;
bar.ColumnWidth = {'1x','1x','1x','1x','1x','1.7x'};
bar.Padding = [0 0 0 0];
bar.BackgroundColor = [0.08 0.10 0.14];

bStart = uibutton(bar,'push','Text','START DEMO','ButtonPushedFcn',@startDemo);
bPause = uibutton(bar,'push','Text','PAUSE','ButtonPushedFcn',@pauseDemo);
bClear = uibutton(bar,'push','Text','CLEAR','ButtonPushedFcn',@clearDemo);
bInvalid = uibutton(bar,'push','Text','INJECT INVALID','ButtonPushedFcn',@injectInvalid);
bTest = uibutton(bar,'push','Text','RUN ALL TESTS','ButtonPushedFcn',@runAllTests);
status = uilabel(bar,'Text','OFFLINE | PAUSED | 0 samples', ...
    'FontColor',[1 0.72 0.3],'HorizontalAlignment','right');

plots = uigridlayout(root,[3 1]);
plots.Layout.Row = 3;
plots.RowHeight = {'1x','1x','1x'};
plots.Padding = [0 0 0 0];
plots.RowSpacing = 6;
plots.BackgroundColor = [0.08 0.10 0.14];

ax = gobjects(1,3);
lineObj = gobjects(1,3);
names = {'Engine RPM','Torque','Power'};
units = {'rpm','N*m','kW'};
for k = 1:3
    ax(k) = uiaxes(plots);
    ax(k).Layout.Row = k;
    ax(k).Color = [0.12 0.15 0.20];
    ax(k).XColor = [0.75 0.81 0.89];
    ax(k).YColor = [0.75 0.81 0.89];
    title(ax(k),names{k},'Color',[0.95 0.97 1]);
    ylabel(ax(k),units{k});
    xlabel(ax(k),'Time (s)');
    grid(ax(k),'on');
    lineObj(k) = plot(ax(k),nan,nan,'LineWidth',1.8);
end

logBox = uitextarea(root,'Editable','off','FontName','Consolas', ...
    'Value',{'[INFO] Step 10.11 initialized'; ...
             '[SAFE] OFFLINE synthetic data only; no Simulink or hardware access'});
logBox.Layout.Row = 4;
footer = uilabel(root,'Text', ...
    'SYNTHETIC DATA ONLY | NOT A HARDWARE SAFETY DEVICE | Torque arm = 0.3048 m', ...
    'FontSize',10,'FontColor',[1 0.72 0.3]);
footer.Layout.Row = 5;

sampleTime = 0.1;
t = zeros(0,1); rpm = zeros(0,1); torque = zeros(0,1); power = zeros(0,1);
counts = struct('START',0,'PAUSE',0,'CLEAR',0,'INVALID',0,'AUTOTEST',0);
lastTest = struct('passed',false,'details',{{}},'samples',0);
running = false;
tickTimer = timer('ExecutionMode','fixedSpacing','Period',sampleTime, ...
    'BusyMode','drop','TimerFcn',@onTick);
setappdata(fig,'DynoForgeStep1011Report',@printReport);
setappdata(fig,'DynoForgeStep1011Test',@runAllTests);

app = struct('Figure',fig,'StartButton',bStart,'PauseButton',bPause, ...
    'ClearButton',bClear,'InvalidButton',bInvalid,'TestButton',bTest, ...
    'Axes',ax,'Report',@printReport,'RunTests',@runAllTests);
fprintf('\n===== STEP 10.11 OFFLINE PLOT =====\n');
fprintf('PASS | Plot window created with 3 axes\n');
fprintf('PASS | Synthetic data only; no Simulink or hardware access\n');
fprintf('Run RUN ALL TESTS, then DynoForge_Realtime_Plot_Test_Report()\n');
fprintf('==================================\n');

    function appendLog(message)
        old = logBox.Value;
        if ischar(old), old = {old}; end
        old{end+1} = message;
        logBox.Value = old(max(1,end-80):end);
    end

    function [ok, vals] = validateSample(tt, rr, ff)
        vals = [nan nan nan];
        ok = isscalar(tt) && isscalar(rr) && isscalar(ff) && ...
             isnumeric(tt) && isnumeric(rr) && isnumeric(ff) && ...
             isreal(tt) && isreal(rr) && isreal(ff) && ...
             all(isfinite([tt rr ff])) && tt >= 0 && ...
             rr >= 0 && rr <= 11000 && ff >= 0 && ff <= 2000;
        if ok
            trq = ff*0.3048;
            pwr = trq*(2*pi*rr/60)/1000;
            vals = [rr trq pwr];
            ok = all(isfinite(vals));
        end
    end

    function accepted = addSample(tt, rr, ff)
        [accepted,vals] = validateSample(tt,rr,ff);
        if ~accepted
            appendLog('[WARN] Invalid sample rejected; plot data unchanged');
            return;
        end
        if ~isempty(t) && tt <= t(end)
            accepted = false;
            appendLog('[WARN] Non-increasing timestamp rejected');
            return;
        end
        t(end+1,1) = tt;
        rpm(end+1,1) = vals(1);
        torque(end+1,1) = vals(2);
        power(end+1,1) = vals(3);
        redraw();
    end

    function redraw()
        series = {rpm,torque,power};
        for q = 1:3
            lineObj(q).XData = t;
            lineObj(q).YData = series{q};
            if isempty(t)
                xlim(ax(q),[0 1]);
            else
                xlim(ax(q),[max(0,t(end)-15) max(1,t(end)+0.5)]);
            end
        end
        if running, mode = 'RUNNING'; else, mode = 'PAUSED'; end
        status.Text = sprintf('OFFLINE | %s | %d samples',mode,numel(t));
        drawnow limitrate;
    end

    function onTick(~,~)
        if ~running || ~isvalid(fig), return; end
        tt = numel(t)*sampleTime;
        rr = min(4500, max(0, 500+1800*(1-exp(-tt/2))+250*sin(tt/2)));
        ff = max(0, 280+75*sin(tt/3));
        addSample(tt,rr,ff);
    end

    function startDemo(~,~)
        if running, return; end
        counts.START = counts.START+1;
        running = true;
        if strcmp(tickTimer.Running,'off'), start(tickTimer); end
        appendLog('[DEMO] Synthetic stream started');
        redraw();
    end

    function pauseDemo(~,~)
        counts.PAUSE = counts.PAUSE+1;
        running = false;
        if strcmp(tickTimer.Running,'on'), stop(tickTimer); end
        appendLog('[DEMO] Synthetic stream paused');
        redraw();
    end

    function clearDemo(~,~)
        counts.CLEAR = counts.CLEAR+1;
        running = false;
        if strcmp(tickTimer.Running,'on'), stop(tickTimer); end
        t = zeros(0,1); rpm = t; torque = t; power = t;
        appendLog('[DEMO] Plot buffers cleared');
        redraw();
    end

    function injectInvalid(~,~)
        counts.INVALID = counts.INVALID+1;
        if running, pauseDemo(); end
        nextT = numel(t)*sampleTime;
        addSample(nextT,NaN,100);
        addSample(nextT,Inf,100);
        addSample(nextT,-1,100);
        appendLog('[DEMO] NaN, Inf, and negative RPM injection attempted');
    end

    function runAllTests(~,~)
        counts.AUTOTEST = counts.AUTOTEST+1;
        running = false;
        if strcmp(tickTimer.Running,'on'), stop(tickTimer); end
        t = zeros(0,1); rpm = t; torque = t; power = t;
        redraw();
        labels = {'NORMAL','ZERO_RPM','NEGATIVE_RPM','NAN','INF', ...
                  'OUT_OF_RANGE','TIME_ORDER','CONSISTENCY','CLEAR'};
        checks = false(1,numel(labels));
        checks(1) = addSample(0,3000,500);
        expectedT = 500*0.3048;
        expectedP = expectedT*(2*pi*3000/60)/1000;
        checks(1) = checks(1) && abs(torque(end)-expectedT)<1e-10 && ...
                    abs(power(end)-expectedP)<1e-10;
        checks(2) = addSample(0.1,0,500) && power(end)==0;
        n = numel(t);
        checks(3) = ~addSample(0.2,-1,500) && numel(t)==n;
        checks(4) = ~addSample(0.2,NaN,500) && numel(t)==n;
        checks(5) = ~addSample(0.2,Inf,500) && numel(t)==n;
        checks(6) = ~addSample(0.2,11001,500) && numel(t)==n;
        checks(7) = ~addSample(0.1,3000,500) && numel(t)==n;
        checks(8) = numel(t)==2 && numel(rpm)==2 && ...
            numel(torque)==2 && numel(power)==2 && ...
            all(isfinite([rpm;torque;power])) && ...
            all(abs(power-torque.*(2*pi*rpm/60)/1000)<1e-10);
        clearDemo();
        checks(9) = isempty(t) && isempty(rpm) && isempty(torque) && isempty(power);
        details = cell(1,numel(labels));
        for j = 1:numel(labels)
            if checks(j), verdict = 'PASS'; else, verdict = 'FAIL'; end
            details{j} = sprintf('%s | %s',verdict,labels{j});
            appendLog(['[TEST] ' details{j}]);
        end
        lastTest = struct('passed',all(checks),'details',{details}, ...
            'samples',numel(checks));
        if lastTest.passed
            appendLog('[TEST] STEP 10.11 OFFLINE PLOTTING TEST PASSED');
        else
            appendLog('[TEST] STEP 10.11 OFFLINE PLOTTING TEST FAILED');
        end
        printReport();
    end

    function printReport()
        fprintf('\n===== STEP 10.11 OFFLINE VERIFICATION =====\n');
        if isempty(lastTest.details)
            fprintf('NOT TESTED | Click RUN ALL TESTS first.\n');
        else
            for j = 1:numel(lastTest.details)
                fprintf('%s\n',lastTest.details{j});
            end
            if lastTest.passed
                fprintf('STEP 10.11 OFFLINE PLOTTING TEST PASSED\n');
            else
                fprintf('STEP 10.11 OFFLINE PLOTTING TEST FAILED\n');
            end
        end
        fprintf('Live Simulink data: NOT TESTED\n');
        fprintf('Hardware data: NOT TESTED\n');
        fprintf('==========================================\n');
    end

    function closeWindow(~,~)
        running = false;
        if isvalid(tickTimer)
            if strcmp(tickTimer.Running,'on'), stop(tickTimer); end
            delete(tickTimer);
        end
        delete(fig);
    end
end
