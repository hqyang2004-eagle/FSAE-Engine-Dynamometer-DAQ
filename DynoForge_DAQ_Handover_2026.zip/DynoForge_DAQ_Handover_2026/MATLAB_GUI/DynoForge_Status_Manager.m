function app = DynoForge_Status_Manager()
% DynoForge Step 10.5 - OFFLINE state monitoring prototype.
% No Simulink writes, model simulation, or hardware access.
% State transitions here are UI demonstrations, not controller outputs.

states = {'IDLE','READY','RUNNING','STOPPING','FAULT'};
colors = [0.58 0.68 0.82; 0.24 0.67 0.88; 0.18 0.72 0.43; ...
          0.96 0.63 0.21; 0.96 0.31 0.31];
counts = zeros(1,5);
history = [];
fig = uifigure('Name','DynoForge | Step 10.5 State Monitor', ...
    'Position',[160 120 840 540], 'Color',[0.08 0.10 0.14]);
layout = uigridlayout(fig,[6 1]);
layout.RowHeight = {50,90,40,75,'1x',28};
layout.Padding = [20 16 20 16];
layout.RowSpacing = 12;
layout.BackgroundColor = [0.08 0.10 0.14];

header = uilabel(layout,'Text','DYNOFORGE | TEST STATE MONITOR', ...
    'FontSize',23,'FontWeight','bold','FontColor',[1 1 1]);
header.Layout.Row = 1;
stateLabel = uilabel(layout,'Text','OFFLINE - NO STATE DATA', ...
    'FontSize',29,'FontWeight','bold','FontColor',[0.96 0.68 0.28], ...
    'HorizontalAlignment','center');
stateLabel.Layout.Row = 2;
info = uilabel(layout,'Text','Source: OFFLINE DEMONSTRATION | Controller: DISCONNECTED', ...
    'FontColor',[0.72 0.80 0.91],'HorizontalAlignment','center');
info.Layout.Row = 3;

buttons = uigridlayout(layout,[1 6]);
buttons.Layout.Row = 4;
buttons.ColumnWidth = {'1x','1x','1x','1x','1x','1x'};
buttons.BackgroundColor = [0.08 0.10 0.14];
for i = 1:5
    idx = i;
    b = uibutton(buttons,'push','Text',sprintf('%d %s',i-1,states{i}), ...
        'ButtonPushedFcn',@(~,~) showState(idx-1));
    b.BackgroundColor = colors(i,:);
    b.FontColor = [1 1 1];
    b.FontWeight = 'bold';
end
uibutton(buttons,'push','Text','CLEAR', ...
    'ButtonPushedFcn',@(~,~) clearHistory());

logBox = uitextarea(layout,'Editable','off', ...
    'Value',{'[INFO] Offline state monitor initialized', ...
             '[SAFE] Buttons only display hypothetical states'});
logBox.Layout.Row = 5;
footer = uilabel(layout,'Text','Not a safety controller. FAULT display does not reset real fault latches.', ...
    'FontSize',11,'FontColor',[0.80 0.84 0.90]);
footer.Layout.Row = 6;

setappdata(fig,'DynoForgeStateReport',@report);
app = struct('Figure',fig,'ShowState',@showState,'Report',@report);
fprintf('\n===== STEP 10.5 STATE MONITOR =====\n');
fprintf('PASS | Offline window created\n');
fprintf('PASS | Five state buttons installed\n');
fprintf('PASS | No Simulink or hardware access\n');
fprintf('Click states 0 through 4, then run: DynoForge_Status_Test_Report\n');

    function showState(code)
        validateattributes(code,{'numeric'},{'scalar','integer','>=',0,'<=',4});
        n = double(code)+1;
        counts(n) = counts(n)+1;
        history(end+1) = code;
        stateLabel.Text = sprintf('STATE %d | %s',code,states{n});
        stateLabel.FontColor = colors(n,:);
        logBox.Value = [logBox.Value; {sprintf('[DEMO] State code %d -> %s (not from Simulink)',code,states{n})}];
    end

    function clearHistory()
        counts = zeros(1,5);
        history = [];
        stateLabel.Text = 'OFFLINE - NO STATE DATA';
        stateLabel.FontColor = [0.96 0.68 0.28];
        logBox.Value = {'[INFO] Demo state history cleared'};
    end

    function report()
        fprintf('\n===== STEP 10.5 OFFLINE VERIFICATION =====\n');
        for j = 1:5
            if counts(j)>0
                fprintf('PASS | State %d (%s) displayed %d time(s)\n',j-1,states{j},counts(j));
            else
                fprintf('FAIL | State %d (%s) not tested\n',j-1,states{j});
            end
        end
        if all(counts>0)
            fprintf('STEP 10.5 OFFLINE DISPLAY TEST PASSED\n');
        else
            fprintf('STEP 10.5 INCOMPLETE - click all five state buttons\n');
        end
        fprintf('Controller state transitions: NOT TESTED HERE\n');
        fprintf('========================================\n');
    end
end
