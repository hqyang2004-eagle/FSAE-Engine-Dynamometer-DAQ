function R = DynoForge_Safety_Snapshot_Check(D)
% Step 10.14C-4. Read-only safety/display consistency checker.
% Not a hardware safety certification. No model access or commands.
required = {'SEQ_State','SEQ_Active','SEQ_Ready','SEQ_Permit', ...
    'SEQ_Fault_Latched','ALM_Level','ALM_Code','ALM_Shutdown', ...
    'CAL_Calibration_Complete','CAL_All_Params_Valid', ...
    'SQ_All_Sensors_OK','SQ_Quality_Fault_Code'};
if ~isstruct(D) || ~isfield(D,'Signals') || ~isstruct(D.Signals)
    error('DynoForge:InvalidSnapshot','Dashboard.Signals must be a struct.');
end
for k=1:numel(required)
    n=required{k};
    if ~isfield(D.Signals,n),error('DynoForge:MissingSignal','Missing %s',n);end
    s=D.Signals.(n);
    if ~isstruct(s) || ~isfield(s,'Value') || ~isfield(s,'Time_s') || ...
       ~isnumeric(s.Value) || ~isnumeric(s.Time_s) || ...
       isempty(s.Value) || numel(s.Value)~=numel(s.Time_s) || ...
       any(~isfinite(s.Value(:))) || any(~isfinite(s.Time_s(:))) || ...
       any(diff(s.Time_s(:))<=0)
        error('DynoForge:InvalidSignal','Invalid samples for %s',n);
    end
end
getv = @(n) double(D.Signals.(n).Value(end));
state=getv('SEQ_State'); active=getv('SEQ_Active');
ready=getv('SEQ_Ready'); permit=getv('SEQ_Permit');
latched=getv('SEQ_Fault_Latched'); alarm=getv('ALM_Level');
code=getv('ALM_Code'); shutdown=getv('ALM_Shutdown');
cal=getv('CAL_Calibration_Complete'); params=getv('CAL_All_Params_Valid');
quality=getv('SQ_All_Sensors_OK'); qcode=getv('SQ_Quality_Fault_Code');
checks = struct();
checks.ValidState = state==floor(state) && ismember(state,0:4);
checks.ValidAlarmLevel = alarm==floor(alarm) && ismember(alarm,0:3);
checks.ValidCodes = code==floor(code) && code>=0 && ...
    qcode==floor(qcode) && qcode>=0;
flags=[active ready permit latched shutdown cal params quality];
checks.BooleanFlags = all(ismember(flags,[0 1]));
checks.FaultNotReadyOrPermitted = ~(state==4 && (ready~=0 || permit~=0 || active~=0));
checks.FaultLatchConsistent = ~(state==4 && latched==0);
checks.ShutdownAlarmConsistent = ~(shutdown==1 && alarm~=3);
checks.CalibrationNotMisrepresented = ~isfield(D,'SensorCalibrationVerified') || ...
    isequal(D.SensorCalibrationVerified,false);
checks.HardwareNotMisrepresented = ~isfield(D,'HardwareVerified') || ...
    isequal(D.HardwareVerified,false);
checks.SourceDeclared = isfield(D,'Source') && ...
    strcmp(D.Source,'SIMULINK_DESKTOP_SIMULATION');
% Alarm bitmask meanings are not asserted: their mapping has not been
% independently verified against the Simulink Alarm Manager implementation.
checks.AlarmCodeNotDecodedWithoutSpecification = true;
labels={'IDLE','READY','RUNNING','STOPPING','FAULT'};
if checks.ValidState, stateText=labels{state+1};else,stateText='INVALID';end
names=fieldnames(checks); failed=names(~cellfun(@(n) checks.(n),names));
R=struct('Passed',isempty(failed),'Checks',checks,'FailedChecks',{failed}, ...
    'State',state,'StateText',stateText,'AlarmLevel',alarm, ...
    'AlarmCodeRaw',code,'QualityCodeRaw',qcode, ...
    'ModelCalibrationComplete',cal==1, ...
    'PhysicalCalibrationVerified',false,'HardwareVerified',false, ...
    'AlarmCodeMappingVerified',false, ...
    'Warning','Alarm code bitmask mapping not independently verified.');
end
